#engine v8

#feature-id    MK Scripts > Colorize by Mask
#feature-info  Advanced Color Tinting tool with Split-Toning, Mask Blurring, and Luminance Protection.
#feature-icon  colorize.svg

#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/SampleType.jsh>

//---------------------------------------------------------
// Color Picker Control (Renders the HSV Box and Hue Strip)
//---------------------------------------------------------
var ColorPickerControl = class extends Control
{
   constructor( parent, initialHue = 0.0 )
   {
      super( parent );
      this.setMinSize( 285, 256 );
      this.setMaxSize( 285, 256 );

      this.hue = initialHue;
      this.sat = 1.0;
      this.val = 1.0;

      this.svBitmap = null;
      this.hBitmap = null;
      this.onColorSelected = null;

      this.generateHStrip();
      this.generateSVBox();

      this.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let g = new Graphics( this );
         if (this.svBitmap) g.drawBitmap( 0, 0, this.svBitmap );
         if (this.hBitmap)  g.drawBitmap( 262, 0, this.hBitmap );

         let sx = Math.round( this.sat * 255 );
         let sy = Math.round( (1 - this.val) * 255 );

         g.pen = new Pen( 0xffffffff, 1 );
         g.drawEllipse( sx - 5, sy - 5, sx + 5, sy + 5 );
         g.pen = new Pen( 0xff000000, 1 );
         g.drawEllipse( sx - 4, sy - 4, sx + 4, sy + 4 );

         let hy = Math.round( (1 - this.hue) * 255 );
         g.pen = new Pen( 0xff000000, 1 );
         g.brush = new Brush( 0xffffffff );
         g.drawPolygon( [
            new Point( 252, hy - 6 ),
            new Point( 260, hy ),
            new Point( 252, hy + 6 )
         ] );
         g.brush = new Brush( 0x00000000 );

         g.end();
      };

      this.onMousePress = ( x, y ) => this.handleMouse( x, y );
      this.onMouseMove = ( x, y, buttons ) => { if ( buttons === 1 ) this.handleMouse( x, y ); };
   }

   HSVtoRGB_float(h, s, v) {
      let r, g, b, i, f, p, q, t;
      i = Math.floor(h * 6);
      f = h * 6 - i;
      p = v * (1 - s);
      q = v * (1 - f * s);
      t = v * (1 - (1 - f) * s);
      switch (i % 6) {
         case 0: r = v, g = t, b = p; break;
         case 1: r = q, g = v, b = p; break;
         case 2: r = p, g = v, b = t; break;
         case 3: r = p, g = q, b = v; break;
         case 4: r = t, g = p, b = v; break;
         case 5: r = v, g = p, b = q; break;
      }
      return { r: r, g: g, b: b };
   }

   RGBtoHSV_float(r, g, b) {
      let max = Math.max(r, g, b), min = Math.min(r, g, b);
      let h, s, v = max;
      let d = max - min;
      s = max === 0 ? 0 : d / max;
      if (max === min) {
         h = 0; // achromatic
      } else {
         switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            case b: h = (r - g) / d + 4; break;
         }
         h /= 6;
      }
      return { h: h, s: s, v: v };
   }

   generateHStrip() {
      let img = new Image( 20, 256, 3, ColorSpace_RGB, 32, SampleType_Real );
      for ( let y = 0; y < 256; y++ ) {
         let h = (255 - y) / 255.0;
         let rgb = this.HSVtoRGB_float( h, 1, 1 );
         for ( let x = 0; x < 20; x++ ) {
            img.setSample( rgb.r, x, y, 0 );
            img.setSample( rgb.g, x, y, 1 );
            img.setSample( rgb.b, x, y, 2 );
         }
      }
      this.hBitmap = img.render();
   }

   generateSVBox() {
      let img = new Image( 256, 256, 3, ColorSpace_RGB, 32, SampleType_Real );
      for ( let y = 0; y < 256; y++ ) {
         let v = (255 - y) / 255.0;
         for ( let x = 0; x < 256; x++ ) {
            let s = x / 255.0;
            let rgb = this.HSVtoRGB_float( this.hue, s, v );
            img.setSample( rgb.r, x, y, 0 );
            img.setSample( rgb.g, x, y, 1 );
            img.setSample( rgb.b, x, y, 2 );
         }
      }
      this.svBitmap = img.render();
   }

   handleMouse( x, y ) {
      if ( x >= 250 ) {
         this.hue = 1.0 - (Math.max( 0, Math.min( 255, y ) ) / 255.0);
         this.generateSVBox();
         this.update();
         if ( this.onColorSelected ) this.onColorSelected( this.getColor() );
      } else if ( x < 250 ) {
         this.sat = Math.max( 0, Math.min( 255, x ) ) / 255.0;
         this.val = 1.0 - (Math.max( 0, Math.min( 255, y ) ) / 255.0);
         this.update();
         if ( this.onColorSelected ) this.onColorSelected( this.getColor() );
      }
   }

   getColor() {
      return this.HSVtoRGB_float( this.hue, this.sat, this.val );
   }
};

//---------------------------------------------------------
// ImagePreviewControl Class (UI-Based Smooth Zoom Engine)
//---------------------------------------------------------
var ImagePreviewControl = class extends ScrollBox
{
   constructor( parent )
   {
      super( parent );
      this.bmp = null;

      this.dragging = false;
      this.dragOrigin = new Point( 0, 0 );
      this.mouseButton = 0;

      this.viewport.cursor = new Cursor( StdCursor_Arrow );

      this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let g = new Graphics( this.viewport );
         g.fillRect( x0, y0, x1, y1, new Brush( 0xff151515 ) );

         if ( this.bmp != null && this.parentDialog )
         {
            let drawW = Math.round(this.bmp.width * this.parentDialog.zoomScale);
            let drawH = Math.round(this.bmp.height * this.parentDialog.zoomScale);
            let rect = new Rect( -this.scrollPosition.x, -this.scrollPosition.y, -this.scrollPosition.x + drawW, -this.scrollPosition.y + drawH );

            g.drawScaledBitmap( rect, this.bmp );
         }
         g.end();
      };

      this.onHorizontalScrollPosUpdated = x => this.viewport.update();
      this.onVerticalScrollPosUpdated = y => this.viewport.update();

      this.viewport.onMouseWheel = ( x, y, delta, button, modifiers ) =>
      {
         if (!this.parentDialog || !this.bmp) return;
         let zoomFactor = 1.15;
         let newScale = this.parentDialog.zoomScale * (delta > 0 ? zoomFactor : 1/zoomFactor);
         this.updateZoom(newScale, x, y);
      };

      this.viewport.onMouseDoubleClick = ( x, y, button, buttons, modifiers ) =>
      {
         if ( this.parentDialog ) this.parentDialog.zoomToFit();
      };

      this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
      {
         if ( modifiers !== 0 ) {
            if ( this.parentDialog ) this.parentDialog.toggleOriginal();
            return;
         }

         this.dragOrigin = new Point( x, y );
         this.dragging = false;
         this.mouseButton = button;
         if ( button === 1 || button === 2 || button === 4 ) this.viewport.cursor = new Cursor( StdCursor_ClosedHand );
      };

      this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
      {
         if ( this.mouseButton === 1 || this.mouseButton === 2 || this.mouseButton === 4 )
         {
            if ( Math.abs(x - this.dragOrigin.x) > 2 || Math.abs(y - this.dragOrigin.y) > 2 )
               this.dragging = true;

            if ( this.dragging )
            {
               let dx = this.dragOrigin.x - x;
               let dy = this.dragOrigin.y - y;
               this.scrollPosition = new Point( this.scrollPosition.x + dx, this.scrollPosition.y + dy );
               this.dragOrigin = new Point( x, y );
            }
         }
      };

      this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
      {
         this.mouseButton = 0;
         this.dragging = false;
         this.viewport.cursor = new Cursor( StdCursor_Arrow );
      };
   }

   updateImage( img )
   {
      if ( !img )
      {
         this.bmp = null;
         this.setHorizontalScrollRange( 0, 0 );
         this.setVerticalScrollRange( 0, 0 );
      }
      else
      {
         this.bmp = img.render();
         if (this.parentDialog) this.updateZoom(this.parentDialog.zoomScale);
      }
      this.viewport.update();
   }

   updateZoom(newScale, cursorX, cursorY)
   {
      if (!this.bmp || !this.parentDialog) return;

      let oldScale = this.parentDialog.zoomScale;

      this.parentDialog.zoomScale = Math.max(this.parentDialog.minScale, Math.min(8.0, newScale));

      let drawW = Math.round(this.bmp.width * this.parentDialog.zoomScale);
      let drawH = Math.round(this.bmp.height * this.parentDialog.zoomScale);

      let maxScrollX = Math.max( 0, drawW - this.viewport.width );
      let maxScrollY = Math.max( 0, drawH - this.viewport.height );

      this.setHorizontalScrollRange( 0, maxScrollX );
      this.setVerticalScrollRange( 0, maxScrollY );

      if (cursorX !== undefined && cursorY !== undefined) {
         let ratio = this.parentDialog.zoomScale / oldScale;
         let newScrollX = Math.round((this.scrollPosition.x + cursorX) * ratio - cursorX);
         let newScrollY = Math.round((this.scrollPosition.y + cursorY) * ratio - cursorY);

         this.scrollPosition = new Point(
             Math.max(0, Math.min(maxScrollX, newScrollX)),
             Math.max(0, Math.min(maxScrollY, newScrollY))
         );
      }

      this.viewport.update();
      this.parentDialog.zoomPctLabel.text = Math.round(this.parentDialog.zoomScale * 100) + "%";
   }
};

//---------------------------------------------------------
// Color Patch Control (Shows Final RGB Output)
//---------------------------------------------------------
var ColorPatch = class extends Control
{
   constructor( parent )
   {
      super( parent );
      this.setMinSize( 45, 22 );
      this.setMaxSize( 45, 22 );
      this.currentColor = {r:1, g:0, b:0};

      this.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let g = new Graphics( this );
         let r8 = Math.round( this.currentColor.r * 255 );
         let g8 = Math.round( this.currentColor.g * 255 );
         let b8 = Math.round( this.currentColor.b * 255 );
         let color = 0xff000000 | (r8 << 16) | (g8 << 8) | b8;
         g.fillRect( x0, y0, x1, y1, new Brush( color ) );
         g.pen = new Pen( 0xffffffff, 1 );
         g.drawRect( x0, y0, x1, y1 );
         g.end();
      };
   }

   setColor( colorObj )
   {
      this.currentColor = colorObj;
      this.update();
   }
};

//---------------------------------------------------------
// Main Dialog
//---------------------------------------------------------
var ColorizeDialog = class extends Dialog
{
   constructor()
   {
      super();

      this.windowTitle = "Colorize By Mask Pro";
      this.userResizable = false;

      this.maskOpacity = 0.20;
      this.debounceDelay = 0.50;
      this.showingOriginal = false;

      this.zoomScale = 1.0;
      this.minScale = 0.01;

      this.selectedColor = { r: 1.0, g: 0.0, b: 0.0 };
      this.selectedShadowColor = { r: 0.0, g: 0.0, b: 1.0 };

      this.srcWin = null;
      this.resWin = null;

      this.updateTimer = new Timer();
      this.updateTimer.periodic = false;
      this.updateTimer.onTimeout = () => { this.refreshResult(); };

      this.onReturn = () => this.cleanUp();

      this.buildUI();
      this.adjustToContents();
      this.updateTargetImage();
   }

   triggerUpdate()
   {
      this.updateTimer.stop();
      if ( this.debounceDelay <= 0.001 ) this.refreshResult();
      else
      {
         this.updateTimer.interval = this.debounceDelay;
         this.updateTimer.start();
      }
   }

   createColorPickerUI(titleText, isShadow)
   {
      let box = new GroupBox(this);
      box.title = titleText;
      let sizer = new VerticalSizer;
      sizer.margin = 10;
      sizer.spacing = 10;

      let picker = new ColorPickerControl(this, isShadow ? 0.6666 : 0.0);
      let colorPatch = new ColorPatch(this);

      let rLbl = new Label(this); rLbl.text = "R:";
      let rEdit = new Edit(this); rEdit.setFixedWidth(36); rEdit.toolTip = "Red (0-255)";
      let gLbl = new Label(this); gLbl.text = "G:";
      let gEdit = new Edit(this); gEdit.setFixedWidth(36); gEdit.toolTip = "Green (0-255)";
      let bLbl = new Label(this); bLbl.text = "B:";
      let bEdit = new Edit(this); bEdit.setFixedWidth(36); bEdit.toolTip = "Blue (0-255)";

      let defaultC = picker.getColor();
      if (isShadow) this.selectedShadowColor = defaultC;
      else this.selectedColor = defaultC;

      colorPatch.setColor(defaultC);

      rEdit.text = Math.round(defaultC.r * 255).toString();
      gEdit.text = Math.round(defaultC.g * 255).toString();
      bEdit.text = Math.round(defaultC.b * 255).toString();

      let updateFromRGB = () => {
         let rVal = Math.max(0, Math.min(255, parseInt(rEdit.text) || 0));
         let gVal = Math.max(0, Math.min(255, parseInt(gEdit.text) || 0));
         let bVal = Math.max(0, Math.min(255, parseInt(bEdit.text) || 0));

         let rF = rVal / 255.0;
         let gF = gVal / 255.0;
         let bF = bVal / 255.0;

         // Keep text synced and perfectly formatted 0-255
         rEdit.text = rVal.toString();
         gEdit.text = gVal.toString();
         bEdit.text = bVal.toString();

         // Push RGB math backward into HSV coordinates to dynamically move the circle/triangle!
         let hsv = picker.RGBtoHSV_float(rF, gF, bF);
         picker.hue = hsv.h;
         picker.sat = hsv.s;
         picker.val = hsv.v;
         picker.generateSVBox();
         picker.update();

         let cObj = { r: rF, g: gF, b: bF };
         if (isShadow) this.selectedShadowColor = cObj;
         else this.selectedColor = cObj;
         colorPatch.setColor(cObj);

         this.triggerUpdate();
      };

      rEdit.onEditCompleted = updateFromRGB;
      gEdit.onEditCompleted = updateFromRGB;
      bEdit.onEditCompleted = updateFromRGB;

      picker.onColorSelected = (c) => {
         if (isShadow) this.selectedShadowColor = c;
         else this.selectedColor = c;
         colorPatch.setColor(c);

         // Update the edit boxes dynamically when user drags on the map
         rEdit.text = Math.round(c.r * 255).toString();
         gEdit.text = Math.round(c.g * 255).toString();
         bEdit.text = Math.round(c.b * 255).toString();

         this.triggerUpdate();
      };

      let h1 = new HorizontalSizer; h1.addStretch(); h1.add(picker); h1.addStretch();

      let h2 = new HorizontalSizer;
      let lbl = new Label(this); lbl.text = "Selected:";
      h2.add(lbl);
      h2.add(colorPatch);
      h2.addSpacing(10);
      h2.add(rLbl); h2.add(rEdit); h2.addSpacing(4);
      h2.add(gLbl); h2.add(gEdit); h2.addSpacing(4);
      h2.add(bLbl); h2.add(bEdit);
      h2.addStretch();

      sizer.add(h1);
      sizer.add(h2);
      box.sizer = sizer;

      return { box: box, picker: picker, patch: colorPatch };
   }

   buildUI()
   {
      let windows = ImageWindow.windows;
      let viewIds = windows.map( w => w.mainView.id );

      this.titleLabel = new Label( this );
      this.titleLabel.text = "Colorize By Mask V1.0\n© Mohammed Khalifa (mhk.astro) - 2026";
      this.titleLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
      this.titleLabel.styleSheet = "QLabel { background-color: #1A365D; color: #FFFFFF; font-weight: bold; font-size: 9pt; padding: 6px; }";

      this.instructionsBox = new GroupBox( this );
      this.instructionsBox.title = "Instructions";
      let instructionsText = new Label( this.instructionsBox );
      instructionsText.text =
         "1. Select your Target and Mask. Turn on Auto-STF for linear images.\n" +
         "2. Pick a color. Check 'Split-Toning' to map different colors to highlights/shadows.\n" +
         "3. Adjust Blend Mode, Opacity, and Render Delay.\n" +
         "4. Turn on 'Preserve Luminance' to protect the brightness of your deep sky details.";
      let instSizer = new VerticalSizer;
      instSizer.margin = 6;
      instSizer.add( instructionsText );
      this.instructionsBox.sizer = instSizer;

      // ---- Image Selectors & Auto-STF ----
      let imgSizer = new HorizontalSizer;
      imgSizer.spacing = 6;
      this.imageLabel = new Label( this );
      this.imageLabel.text = "Target Image:";
      this.imageLabel.minWidth = 100;
      this.imageCombo = new ComboBox( this );
      viewIds.forEach( id => this.imageCombo.addItem( id ) );
      this.imageCombo.onItemSelected = () => this.updateTargetImage();

      this.imageCombo.toolTip = "Select the base image you want to colorize. (The target layer)";
      this.imageLabel.toolTip = this.imageCombo.toolTip;

      imgSizer.add( this.imageLabel );
      imgSizer.add( this.imageCombo, 100 );

      let maskSizer = new HorizontalSizer;
      maskSizer.spacing = 6;
      this.maskLabel = new Label( this );
      this.maskLabel.text = "Mask Image:";
      this.maskLabel.minWidth = 100;
      this.maskCombo = new ComboBox( this );
      this.maskCombo.addItem( "<None>" );

      let autoMaskIndex = 0;
      viewIds.forEach( (id, index) => {
         this.maskCombo.addItem( id );
         if ( autoMaskIndex === 0 && id.toLowerCase().includes("mask") ) {
            autoMaskIndex = index + 1;
         }
      });
      this.maskCombo.currentItem = autoMaskIndex;
      this.maskCombo.onItemSelected = () => this.triggerUpdate();

      this.maskCombo.toolTip = "Select the mask to restrict where the color is applied.";
      this.maskLabel.toolTip = this.maskCombo.toolTip;

      maskSizer.add( this.maskLabel );
      maskSizer.add( this.maskCombo, 100 );

      this.linearImage_Cb = new CheckBox( this );
      this.linearImage_Cb.text = "Auto-Stretch Previews (STF for Linear Data)";
      this.linearImage_Cb.checked = false;
      this.linearImage_Cb.onCheck = () => this.updateSinglePreview();
      this.linearImage_Cb.toolTip = "Applies a temporary Screen Transfer Function (STF) to the preview window.\nTurn this on if you are coloring linear (unstretched) data.";

      this.compactUI_Cb = new CheckBox( this );
      this.compactUI_Cb.text = "Compact UI";
      this.compactUI_Cb.checked = false;
      this.compactUI_Cb.onCheck = () => this.initLayoutForImage();
      this.compactUI_Cb.toolTip = "Reduces the maximum preview window size, fitting the script comfortably on smaller screens.";

      // ---- Color Pickers & Split Toning ----
      this.hlPicker = this.createColorPickerUI("Main Color", false);
      this.shPicker = this.createColorPickerUI("Shadow Color", true);
      this.shPicker.box.visible = false;

      let pickersSizer = new HorizontalSizer;
      pickersSizer.spacing = 10;
      pickersSizer.add(this.hlPicker.box, 100);
      pickersSizer.add(this.shPicker.box, 100);

      // ---- Blend Controls & Sub-Toggles ----
      const SLIDER_LABEL_WIDTH = 110;
      const EDIT_WIDTH = 45;

      this.blendLabel = new Label( this );
      this.blendLabel.text = "Blend Mode:";
      this.blendLabel.minWidth = SLIDER_LABEL_WIDTH;
      this.blendCombo = new ComboBox( this );
      this.blendCombo.addItem( "Multiply" );
      this.blendCombo.addItem( "Screen" );
      this.blendCombo.addItem( "Overlay" );
      this.blendCombo.addItem( "Linear Dodge" );
      this.blendCombo.addItem( "Normal (Solid Paint)" );
      this.blendCombo.currentItem = 0;
      this.blendCombo.onItemSelected = () => this.triggerUpdate();

      this.blendCombo.toolTip = "Determines how the color interacts with your image.\n\n- Multiply: Darkens/Tints\n- Screen: Brightens\n- Overlay: Enhances contrast\n- Linear Dodge: Adds raw brightness\n- Normal: Paints solid color";
      this.blendLabel.toolTip = this.blendCombo.toolTip;

      let blendSizer = new HorizontalSizer;
      blendSizer.spacing = 6;
      blendSizer.add( this.blendLabel );
      blendSizer.add( this.blendCombo, 100 );

      this.opacityLabel = new Label( this );
      this.opacityLabel.text = "Blend Opacity:";
      this.opacityLabel.minWidth = SLIDER_LABEL_WIDTH;
      this.opacitySlider = new Slider( this );
      this.opacitySlider.minValue = 0;
      this.opacitySlider.maxValue = 100;
      this.opacitySlider.value = 20;
      this.opacityValue = new Edit( this );
      this.opacityValue.text = "20%";
      this.opacityValue.setFixedWidth( EDIT_WIDTH );

      this.opacitySlider.onValueUpdated = v => {
         this.maskOpacity = v / 100.0;
         this.opacityValue.text = v.toString() + "%";
         this.triggerUpdate();
      };

      let opacityTip = "Controls the strength or transparency of the applied color.";
      this.opacitySlider.toolTip = opacityTip;
      this.opacityValue.toolTip = opacityTip;
      this.opacityLabel.toolTip = opacityTip;

      let opacitySizer = new HorizontalSizer;
      opacitySizer.spacing = 6;
      opacitySizer.add( this.opacityLabel );
      opacitySizer.add( this.opacitySlider, 100 );
      opacitySizer.add( this.opacityValue );

      this.delayLabel = new Label( this );
      this.delayLabel.text = "Render Delay:";
      this.delayLabel.minWidth = SLIDER_LABEL_WIDTH;
      this.delaySlider = new Slider( this );
      this.delaySlider.minValue = 0;
      this.delaySlider.maxValue = 10;
      this.delaySlider.value = Math.round( this.debounceDelay * 10 );
      this.delayValue = new Edit( this );
      this.delayValue.text = format( "%.1fs", this.debounceDelay );
      this.delayValue.setFixedWidth( EDIT_WIDTH );

      this.delaySlider.onValueUpdated = v => {
         this.debounceDelay = v / 10.0;
         this.delayValue.text = format( "%.1fs", this.debounceDelay );
      };

      this.delayValue.onEditCompleted = () => {
         let val = parseFloat( this.delayValue.text );
         if ( isNaN( val ) ) val = 0.5;
         val = Math.max( 0.0, Math.min( 1.0, val ) );
         this.debounceDelay = val;
         this.delayValue.text = format( "%.1fs", this.debounceDelay );
         this.delaySlider.value = Math.round( val * 10 );
      };

      let delayTip = "Sets a delay (in seconds) before updating the preview when sliding controls.\nHigher values prevent lag when working with very large images.";
      this.delaySlider.toolTip = delayTip;
      this.delayValue.toolTip = delayTip;
      this.delayLabel.toolTip = delayTip;

      let delaySizer = new HorizontalSizer;
      delaySizer.spacing = 6;
      delaySizer.add( this.delayLabel );
      delaySizer.add( this.delaySlider, 100 );
      delaySizer.add( this.delayValue );

      // Checkboxes moved into Blend Controls
      this.preserveLum_Cb = new CheckBox( this );
      this.preserveLum_Cb.text = "Preserve Original Luminance";
      this.preserveLum_Cb.checked = false;
      this.preserveLum_Cb.onCheck = () => this.triggerUpdate();
      this.preserveLum_Cb.toolTip = "Protects the original brightness (L*) of the image structures, only injecting the Hue and Saturation of your color.\nHighly recommended for astrophotography to prevent blowing out stars and nebulas.";

      this.splitTone_Cb = new CheckBox( this );
      this.splitTone_Cb.text = "Enable Split-Toning (Highlights vs Shadows)";
      this.splitTone_Cb.checked = false;
      this.splitTone_Cb.onCheck = (checked) => {
         this.shPicker.box.visible = checked;
         this.hlPicker.box.title = checked ? "Highlight Color" : "Main Color";
         this.setFixedSize( 0, 0 );
         this.adjustToContents();
         this.setFixedSize( this.width, this.height );
         this.triggerUpdate();
      };
      this.splitTone_Cb.toolTip = "Reveals a second color picker, allowing you to mathematically map different colors to the highlights and shadows of your masked area.";

      this.controlsBox = new GroupBox( this );
      this.controlsBox.title = "Blend Controls";
      let maskControlsSizer = new VerticalSizer;
      maskControlsSizer.margin = 8;
      maskControlsSizer.spacing = 8;
      maskControlsSizer.add( blendSizer );
      maskControlsSizer.add( opacitySizer );
      maskControlsSizer.add( delaySizer );
      maskControlsSizer.addSpacing( 4 );
      maskControlsSizer.add( this.preserveLum_Cb );
      maskControlsSizer.add( this.splitTone_Cb );
      this.controlsBox.sizer = maskControlsSizer;

      // ---- Action Buttons ----
      this.applyButton = new PushButton( this );
      this.applyButton.text = "Apply Color";
      this.applyButton.defaultButton = true;
      this.applyButton.onClick = () => this.applyColorize();

      this.closeButton = new PushButton( this );
      this.closeButton.text = "Close";
      this.closeButton.onClick = () => this.ok();

      let btnSizer = new HorizontalSizer;
      btnSizer.add( this.applyButton );
      btnSizer.addSpacing( 10 );
      btnSizer.add( this.closeButton );
      btnSizer.addStretch();

      // Assemble Left Panel
      this.leftSizer = new VerticalSizer;
      this.leftSizer.margin = 10;
      this.leftSizer.spacing = 8;
      this.leftSizer.add( this.titleLabel );
      this.leftSizer.add( this.instructionsBox );
      this.leftSizer.addSpacing( 5 );
      this.leftSizer.add( imgSizer );
      this.leftSizer.add( maskSizer );
      this.leftSizer.add( this.linearImage_Cb );
      this.leftSizer.add( this.compactUI_Cb );
      this.leftSizer.addSpacing( 5 );
      this.leftSizer.add( pickersSizer );
      this.leftSizer.addSpacing( 5 );
      this.leftSizer.add( this.controlsBox );
      this.leftSizer.addStretch();
      this.leftSizer.add( btnSizer );

      // ---- Assemble Right Panel (Dynamic Size Preview) ----
      this.preview = new ImagePreviewControl( this );
      this.preview.parentDialog = this;

      this.zoomPctLabel = new Label( this );
      this.zoomPctLabel.text = "100%";
      this.zoomPctLabel.styleSheet = "QLabel { font-weight: bold; color: #000000; }";

      this.headerLbl = new Label(this);
      this.headerLbl.text = "Colorized Output Preview";
      this.headerLbl.styleSheet = "QLabel { font-weight: bold; font-size: 11pt; color: #000000; }";

      let shortcutsLbl = new Label(this);
      shortcutsLbl.text = "- Double-click to zoom out to fit the preview\n- Mouse wheel to zoom\n- Click and drag to pan\n- Ctrl + Click to toggle between preview and original";
      shortcutsLbl.styleSheet = "QLabel { color: #000000; font-size: 9pt; }";

      let zLbl = new Label(this);
      zLbl.text = "Zoom Level:";

      let zoomSizer = new HorizontalSizer;
      zoomSizer.add(zLbl);
      zoomSizer.addSpacing(6);
      zoomSizer.add(this.zoomPctLabel);
      zoomSizer.addStretch();

      // Group the right-side elements
      let rightInfoSizer = new VerticalSizer;
      rightInfoSizer.spacing = 4;
      rightInfoSizer.add(shortcutsLbl);
      rightInfoSizer.add(zoomSizer);

      // Group the left-side header, adding a stretch above it to push it down so it aligns with the bottom of the shortcuts
      let leftHeaderContainer = new VerticalSizer;
      leftHeaderContainer.addStretch();
      leftHeaderContainer.add(this.headerLbl);

      // Assemble the top bar above the image
      let topHeaderSizer = new HorizontalSizer;
      topHeaderSizer.add(leftHeaderContainer);
      topHeaderSizer.addStretch(); // This pushes the shortcuts strictly to the right side!
      topHeaderSizer.add(rightInfoSizer);

      let rightSizer = new VerticalSizer;
      rightSizer.margin = 10;
      rightSizer.spacing = 6;

      rightSizer.add(topHeaderSizer);
      rightSizer.add( this.preview );
      rightSizer.addStretch();

      this.sizer = new HorizontalSizer;
      this.sizer.add( this.leftSizer );
      this.sizer.add( rightSizer );
   }

   initLayoutForImage()
   {
      if ( !this.resWin ) return;
      let img = this.resWin.mainView.image;
      if ( !img ) return;

      // FIX: Increased dimensions to give the Compact UI more room
      let maxW = this.compactUI_Cb.checked ? 550 : 850;
      let maxH = this.compactUI_Cb.checked ? 550 : 850;

      let fitScale = Math.min( maxW / img.width, maxH / img.height );

      let previewW = Math.round( img.width * fitScale );
      let previewH = Math.round( img.height * fitScale );

      // FIX: Fallback safeguard increased from 300 to 350
      let minDim = this.compactUI_Cb.checked ? 350 : 400;
      if (previewW < minDim || previewH < minDim) {
         let upScale = Math.max( minDim / previewW, minDim / previewH );
         previewW = Math.round(previewW * upScale);
         previewH = Math.round(previewH * upScale);
         fitScale *= upScale;
      }

      this.preview.setFixedSize( previewW, previewH );

      this.minScale = fitScale;
      this.zoomScale = this.minScale;
      this.preview.scrollPosition = new Point(0, 0);

      this.setFixedSize( 0, 0 );
      this.adjustToContents();
      this.setFixedSize( this.width, this.height );

      this.updateSinglePreview();
   }

   toggleOriginal()
   {
      if ( !this.srcWin || !this.resWin ) return;

      this.showingOriginal = !this.showingOriginal;

      if ( this.showingOriginal ) {
         this.headerLbl.text = "Source Image (Original)";
         this.headerLbl.styleSheet = "QLabel { font-weight: bold; font-size: 11pt; color: #cc0000; }";
      } else {
         this.headerLbl.text = "Colorized Output Preview";
         this.headerLbl.styleSheet = "QLabel { font-weight: bold; font-size: 11pt; color: #000000; }";
      }

      this.updateSinglePreview();
   }

   zoomToFit()
   {
      this.zoomScale = this.minScale;
      this.preview.scrollPosition = new Point(0, 0);
      this.preview.updateZoom(this.zoomScale);
   }

   cleanUp()
   {
      if ( this.srcWin ) { this.srcWin.forceClose(); this.srcWin = null; }
      if ( this.resWin ) { this.resWin.forceClose(); this.resWin = null; }
   }

   updateTargetImage()
   {
      this.cleanUp();
      if ( this.imageCombo.numberOfItems === 0 ) return;
      let targetId = this.imageCombo.itemText( this.imageCombo.currentItem );
      let targetView = View.viewById( targetId );
      if ( targetView.isNull ) return;

      this.srcWin = new ImageWindow(
         targetView.image.width, targetView.image.height,
         targetView.image.numberOfChannels, targetView.image.bitsPerSample,
         targetView.image.isReal, targetView.image.isColor, "tmp_src_" + Date.now()
      );
      this.srcWin.mainView.beginProcess();
      this.srcWin.mainView.image.assign( targetView.image );
      this.srcWin.mainView.endProcess();

      this.resWin = new ImageWindow(
         targetView.image.width, targetView.image.height,
         3, targetView.image.bitsPerSample,
         targetView.image.isReal, true, "tmp_res_" + Date.now()
      );
      this.resWin.mainView.beginProcess();
      if ( !targetView.image.isColor ) {
         this.resWin.mainView.image.selectedChannel = 0; this.resWin.mainView.image.assign(targetView.image);
         this.resWin.mainView.image.selectedChannel = 1; this.resWin.mainView.image.assign(targetView.image);
         this.resWin.mainView.image.selectedChannel = 2; this.resWin.mainView.image.assign(targetView.image);
         this.resWin.mainView.image.resetSelections();
      } else {
         this.resWin.mainView.image.assign( targetView.image );
      }
      this.resWin.mainView.endProcess();

      this.refreshResult();
      this.initLayoutForImage();
   }

   getChannelExpression( channelIdx, srcId, maskId, opacity, hlColorVal, shColorVal, isSplit )
   {
      let op = opacity.toFixed( 4 );
      let mExpr = op;
      if ( maskId !== "<None>" ) {
         mExpr = `(iif(channels(${maskId})>1, (${maskId}[0]+${maskId}[1]+${maskId}[2])/3, ${maskId}) * ${op})`;
      }

      let bgSafe = `iif(channels(${srcId})>1, ${srcId}[${channelIdx}], ${srcId})`;

      let cV;
      if (isSplit) {
         cV = `((${hlColorVal.toFixed(4)} * CIEL(${srcId})) + (${shColorVal.toFixed(4)} * (1 - CIEL(${srcId}))))`;
      } else {
         cV = hlColorVal.toFixed(4);
      }

      let blend = "";
      switch ( this.blendCombo.currentItem ) {
         case 0: // Multiply
            blend = `${bgSafe} * ${cV}`; break;
         case 1: // Screen
            blend = `1 - (1 - ${bgSafe}) * (1 - ${cV})`; break;
         case 2: // Overlay
            blend = `iif(${bgSafe} > 0.5, 1 - 2*(1 - ${bgSafe})*(1 - ${cV}), 2*${bgSafe}*${cV})`; break;
         case 3: // Add
            blend = `${bgSafe} + ${cV}`; break;
         case 4: // Normal
            blend = cV; break;
      }
      return `${bgSafe} * (1 - ${mExpr}) + (${blend}) * ${mExpr}`;
   }

   refreshResult()
   {
      if ( !this.srcWin || !this.resWin ) return;

      let srcId = this.srcWin.mainView.id;
      let maskId = this.maskCombo.itemText( this.maskCombo.currentItem );

      let tmpWin = new ImageWindow(
         this.srcWin.mainView.image.width, this.srcWin.mainView.image.height,
         3, this.srcWin.mainView.image.bitsPerSample,
         this.srcWin.mainView.image.isReal, true, "tmp_blend_" + Date.now()
      );
      tmpWin.mainView.beginProcess();
      tmpWin.mainView.image.assign(this.srcWin.mainView.image);
      tmpWin.mainView.endProcess();

      var PM = new PixelMath;
      PM.useSingleExpression = false;
      PM.createNewImage = false;

      let isSplit = this.splitTone_Cb.checked;

      PM.expression = this.getChannelExpression(0, srcId, maskId, this.maskOpacity, this.selectedColor.r, this.selectedShadowColor.r, isSplit);
      PM.expression1 = this.getChannelExpression(1, srcId, maskId, this.maskOpacity, this.selectedColor.g, this.selectedShadowColor.g, isSplit);
      PM.expression2 = this.getChannelExpression(2, srcId, maskId, this.maskOpacity, this.selectedColor.b, this.selectedShadowColor.b, isSplit);

      Console.enabled = false;
      try {
         PM.executeOn( tmpWin.mainView );

         if (this.preserveLum_Cb.checked) {
            var PM_L = new PixelMath;
            PM_L.useSingleExpression = false;
            PM_L.createNewImage = false;
            let tId = tmpWin.mainView.id;
            let sId = this.srcWin.mainView.id;

            let ratio = "(CIEL(" + sId + ") / max(0.00001, CIEL(" + tId + ")))";
            PM_L.expression = tId + "[0] * " + ratio;
            PM_L.expression1 = tId + "[1] * " + ratio;
            PM_L.expression2 = tId + "[2] * " + ratio;

            PM_L.executeOn(this.resWin.mainView);
         } else {
            this.resWin.mainView.beginProcess();
            this.resWin.mainView.image.assign(tmpWin.mainView.image);
            this.resWin.mainView.endProcess();
         }
      } finally {
         Console.enabled = true;
         tmpWin.forceClose();
      }

      this.showingOriginal = false;
      this.headerLbl.text = "Colorized Output Preview";
      this.headerLbl.styleSheet = "QLabel { font-weight: bold; font-size: 11pt; color: #000000; }";

      this.updateSinglePreview();
   }

   updateSinglePreview()
   {
      if ( !this.srcWin || !this.resWin ) return;

      let srcImg = this.showingOriginal ? this.srcWin.mainView.image : this.resWin.mainView.image;

      if ( this.linearImage_Cb.checked ) {
         let w = new ImageWindow( srcImg.width, srcImg.height, srcImg.numberOfChannels, srcImg.bitsPerSample, srcImg.isReal, srcImg.isColor );
         w.mainView.beginProcess();
         w.mainView.image.assign( srcImg );
         w.mainView.endProcess();

         var PM = new PixelMath;
         PM.expression = "C = -2.8;\nB = 0.20;\nc = min(max(0,med($T)+C*1.4826*mdev($T)),1);\nmtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
         PM.useSingleExpression = true;
         PM.symbols = "C,B,c";
         PM.createNewImage = false;
         Console.enabled = false;
         PM.executeOn( w.mainView );
         Console.enabled = true;

         this.preview.updateImage( w.mainView.image );
         w.forceClose();
      } else {
         this.preview.updateImage( srcImg );
      }
   }

   applyColorize()
   {
      if ( !this.resWin ) return;
      this.updateTimer.stop();
      this.refreshResult();

      let finalImg = new ImageWindow(
         this.resWin.mainView.image.width,
         this.resWin.mainView.image.height,
         3,
         this.resWin.mainView.image.bitsPerSample,
         this.resWin.mainView.image.isReal,
         true,
         "Colorized_Image"
      );

      finalImg.mainView.beginProcess();
      finalImg.mainView.image.assign( this.resWin.mainView.image );
      finalImg.mainView.endProcess();

      finalImg.show();
      finalImg.zoomToFit();
   }
};

//---------------------------------------------------------
// Main Function
//---------------------------------------------------------
function main()
{
   if ( ImageWindow.windows.length === 0 )
   {
      new MessageBox(
         "Please open at least one image to use the Colorize by Mask script.",
         "Error",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return;
   }

   let dialog = new ColorizeDialog();
   dialog.execute();
   dialog.cleanUp();
}

main();

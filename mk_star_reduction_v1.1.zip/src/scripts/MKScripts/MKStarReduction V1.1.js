#engine v8

#feature-id    MK Scripts > Star Reduction
#feature-icon  mk_star_reduction.svg
#feature-info  Star Reduction using Transfer Method with Interactive Split, Toggle & Navigator Preview.

#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>

const VIEW_MODE_SPLIT    = 0; // Draggable split line
const VIEW_MODE_REDUCED  = 1; // Full reduced view (After)
const VIEW_MODE_ORIGINAL = 2; // Full original view (Before)

//---------------------------------------------------------
// OverviewControl Class (Mini-Map Navigator)
//---------------------------------------------------------
var OverviewControl = class extends Control
{
   constructor( parent )
   {
      super( parent );

      this.bmpThumbnail = null;
      this.mainPreview = null;
      this.imageWidth = 0;
      this.imageHeight = 0;

      this.setMinSize( 130, 130 );
      this.setMaxSize( 130, 130 );

      this.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let g = new Graphics( this );
         g.fillRect( x0, y0, x1, y1, new Brush( 0xff151515 ) );

         if ( this.bmpThumbnail != null && this.imageWidth > 0 && this.imageHeight > 0 && this.mainPreview != null )
         {
            let boxW = this.width;
            let boxH = this.height;

            let scale = Math.min( boxW / this.imageWidth, boxH / this.imageHeight );
            let drawW = Math.round( this.imageWidth * scale );
            let drawH = Math.round( this.imageHeight * scale );

            let offsetX = Math.round( (boxW - drawW) / 2 );
            let offsetY = Math.round( (boxH - drawH) / 2 );

            g.drawBitmap( offsetX, offsetY, this.bmpThumbnail );

            let mainBmp = this.mainPreview.bmpReduced || this.mainPreview.bmpOriginal;
            if ( mainBmp != null && mainBmp.width > 0 && mainBmp.height > 0 )
            {
               let viewW = this.mainPreview.viewport.width;
               let viewH = this.mainPreview.viewport.height;
               let scrollX = this.mainPreview.scrollPosition.x;
               let scrollY = this.mainPreview.scrollPosition.y;

               let fracX = scrollX / mainBmp.width;
               let fracY = scrollY / mainBmp.height;
               let fracW = Math.min( 1.0, viewW / mainBmp.width );
               let fracH = Math.min( 1.0, viewH / mainBmp.height );

               let rectX = offsetX + Math.round( fracX * drawW );
               let rectY = offsetY + Math.round( fracY * drawH );
               let rectW = Math.max( 6, Math.round( fracW * drawW ) );
               let rectH = Math.max( 6, Math.round( fracH * drawH ) );

               rectX = Math.max( offsetX, Math.min( offsetX + drawW - rectW, rectX ) );
               rectY = Math.max( offsetY, Math.min( offsetY + drawH - rectH, rectY ) );

               g.fillRect( rectX, rectY, rectX + rectW, rectY + rectH, new Brush( 0x33ff0000 ) );
               g.pen = new Pen( 0xffff0000, 1.5 );
               g.drawRect( rectX, rectY, rectX + rectW, rectY + rectH );
            }

            g.pen = new Pen( 0xff444444, 1 );
            g.drawRect( 0, 0, boxW, boxH );
         }

         g.end();
      };

      this.onMousePress = ( x, y ) => { this.centerScrollAt( x, y ); };
      this.onMouseMove = ( x, y, buttons ) => { if ( buttons === 1 ) this.centerScrollAt( x, y ); };
   }

   centerScrollAt( x, y )
   {
      if ( this.bmpThumbnail == null || this.mainPreview == null || this.imageWidth <= 0 || this.imageHeight <= 0 ) return;

      let mainBmp = this.mainPreview.bmpReduced || this.mainPreview.bmpOriginal;
      if ( mainBmp == null || mainBmp.width <= 0 || mainBmp.height <= 0 ) return;

      let boxW = this.width;
      let boxH = this.height;
      let scale = Math.min( boxW / this.imageWidth, boxH / this.imageHeight );
      let drawW = Math.round( this.imageWidth * scale );
      let drawH = Math.round( this.imageHeight * scale );

      let offsetX = Math.round( (boxW - drawW) / 2 );
      let offsetY = Math.round( (boxH - drawH) / 2 );

      let relX = Math.max( 0, Math.min( 1.0, (x - offsetX) / Math.max( 1, drawW ) ) );
      let relY = Math.max( 0, Math.min( 1.0, (y - offsetY) / Math.max( 1, drawH ) ) );

      let viewW = this.mainPreview.viewport.width;
      let viewH = this.mainPreview.viewport.height;

      let targetScrollX = Math.round( relX * mainBmp.width - viewW / 2 );
      let targetScrollY = Math.round( relY * mainBmp.height - viewH / 2 );

      targetScrollX = Math.max( 0, Math.min( Math.max(0, mainBmp.width - viewW), targetScrollX ) );
      targetScrollY = Math.max( 0, Math.min( Math.max(0, mainBmp.height - viewH), targetScrollY ) );

      this.mainPreview.scrollPosition = new Point( targetScrollX, targetScrollY );
      this.mainPreview.viewport.update();
      this.update();
   }

   doUpdateThumbnail( baseImage )
   {
      if ( baseImage == null ) return;
      this.imageWidth = baseImage.width;
      this.imageHeight = baseImage.height;

      let boxW = 130;
      let boxH = 130;
      let scale = Math.max( Math.floor( baseImage.width / boxW ), Math.floor( baseImage.height / boxH ) );

      let window = new ImageWindow(
         baseImage.width,
         baseImage.height,
         baseImage.numberOfChannels,
         baseImage.bitsPerSample,
         baseImage.isReal,
         baseImage.isColor
      );

      window.mainView.beginProcess();
      window.mainView.image.assign( baseImage );
      window.mainView.endProcess();

      let P = new IntegerResample;
      P.zoomFactor = -Math.max( 1, scale );
      P.executeOn( window.mainView );

      let thumbImage = new Image( window.mainView.image );
      window.forceClose();

      this.bmpThumbnail = thumbImage.render();
      this.update();
   }
};

//---------------------------------------------------------
// ScrollControl Class (Embedded Interactive Viewer)
//---------------------------------------------------------
var ScrollControl = class extends ScrollBox
{
   constructor( parent )
   {
      super( parent );

      this.autoScroll = true;
      this.tracking = true;

      this.originalImage = null;
      this.reducedImage = null;

      this.bmpOriginal = null;
      this.bmpReduced = null;

      this.viewMode = VIEW_MODE_SPLIT;
      this.splitPosition = 0.5;
      this.dragging = false;
      this.draggingSplit = false;
      this.dragOrigin = new Point( 0, 0 );

      this.viewport.cursor = new Cursor( StdCursor_OpenHand );

      this.viewport.onResize = () => { this.initScrollBars(); };

      this.onHorizontalScrollPosUpdated = x =>
      {
         this.viewport.update();
         if ( this.parent && this.parent.overviewControl )
            this.parent.overviewControl.update();
      };

      this.onVerticalScrollPosUpdated = y =>
      {
         this.viewport.update();
         if ( this.parent && this.parent.overviewControl )
            this.parent.overviewControl.update();
      };

      this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
      {
         if ( this.viewMode === VIEW_MODE_SPLIT )
         {
            let splitX = Math.round( this.viewport.width * this.splitPosition );
            if ( Math.abs( x - splitX ) <= 10 )
            {
               this.draggingSplit = true;
               this.viewport.cursor = new Cursor( StdCursor_Arrow );
               return;
            }
         }

         this.viewport.cursor = new Cursor( StdCursor_ClosedHand );
         this.dragOrigin.x = x;
         this.dragOrigin.y = y;
         this.dragging = true;
      };

      this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
      {
         let splitX = Math.round( this.viewport.width * this.splitPosition );

         if ( this.draggingSplit && this.viewMode === VIEW_MODE_SPLIT )
         {
            this.splitPosition = Math.max( 0.0, Math.min( 1.0, x / Math.max( 1, this.viewport.width ) ) );
            this.viewport.update();
         }
         else if ( this.dragging )
         {
            this.scrollPosition = new Point( this.scrollPosition ).translatedBy(
               this.dragOrigin.x - x,
               this.dragOrigin.y - y
            );
            this.dragOrigin.x = x;
            this.dragOrigin.y = y;

            if ( this.parent && this.parent.overviewControl )
               this.parent.overviewControl.update();
         }
         else
         {
            if ( this.viewMode === VIEW_MODE_SPLIT && Math.abs( x - splitX ) <= 10 )
               this.viewport.cursor = new Cursor( StdCursor_Arrow );
            else
               this.viewport.cursor = new Cursor( StdCursor_OpenHand );
         }
      };

      this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
      {
         this.dragging = false;
         this.draggingSplit = false;

         let splitX = Math.round( this.viewport.width * this.splitPosition );
         if ( this.viewMode === VIEW_MODE_SPLIT && Math.abs( x - splitX ) <= 10 )
            this.viewport.cursor = new Cursor( StdCursor_Arrow );
         else
            this.viewport.cursor = new Cursor( StdCursor_OpenHand );
      };

      this.viewport.onMouseWheel = ( x, y, delta, buttons, modifiers ) =>
      {
         if ( this.parent && this.parent.onPreviewWheelZoom )
            this.parent.onPreviewWheelZoom( delta, x, y, modifiers );
      };

      this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let g = new Graphics( this.viewport );
         g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );

         if ( this.bmpOriginal != null && this.bmpReduced != null )
         {
            let dx = -this.scrollPosition.x;
            let dy = -this.scrollPosition.y;

            if ( this.viewMode === VIEW_MODE_ORIGINAL )
            {
               g.drawBitmap( dx, dy, this.bmpOriginal );
            }
            else if ( this.viewMode === VIEW_MODE_REDUCED )
            {
               g.drawBitmap( dx, dy, this.bmpReduced );
            }
            else
            {
               let splitX = Math.round( this.viewport.width * this.splitPosition );

               g.clipRect = new Rect( 0, 0, splitX, this.viewport.height );
               g.drawBitmap( dx, dy, this.bmpOriginal );

               g.clipRect = new Rect( splitX, 0, this.viewport.width, this.viewport.height );
               g.drawBitmap( dx, dy, this.bmpReduced );

               g.clipRect = new Rect( 0, 0, this.viewport.width, this.viewport.height );

               g.fillRect( splitX - 1, 0, splitX + 2, this.viewport.height, new Brush( 0xff000000 ) );
               g.fillRect( splitX, 0, splitX + 1, this.viewport.height, new Brush( 0xffffffff ) );

               let centerY = Math.round( this.viewport.height / 2 );
               let handleW = 10;
               let handleH = 20;

               g.fillRect( splitX - handleW, centerY - handleH, splitX + handleW, centerY + handleH, new Brush( 0xff1a365d ) );
               g.pen = new Pen( 0xffffffff, 1 );
               g.drawRect( splitX - handleW, centerY - handleH, splitX + handleW, centerY + handleH );

               g.fillRect( splitX - 4, centerY - 8, splitX - 2, centerY + 8, new Brush( 0xffffffff ) );
               g.fillRect( splitX + 2, centerY - 8, splitX + 4, centerY + 8, new Brush( 0xffffffff ) );
            }
         }

         g.end();
      };

      this.initScrollBars();
   }

   setViewMode( mode )
   {
      this.viewMode = mode;
      this.viewport.update();
   }

   getImage()
   {
      return this.reducedImage;
   }

   doUpdateImages( originalImage, reducedImage, cursorX, cursorY )
   {
      let oldW = (this.bmpOriginal != null) ? this.bmpOriginal.width : 0;
      let oldH = (this.bmpOriginal != null) ? this.bmpOriginal.height : 0;

      this.originalImage = originalImage;
      this.reducedImage = reducedImage;

      if (this.originalImage) this.bmpOriginal = this.originalImage.render();
      if (this.reducedImage) this.bmpReduced = this.reducedImage.render();

      let newW = (this.bmpOriginal != null) ? this.bmpOriginal.width : 0;
      let newH = (this.bmpOriginal != null) ? this.bmpOriginal.height : 0;

      let maxScrollX = Math.max( 0, newW - this.viewport.width );
      let maxScrollY = Math.max( 0, newH - this.viewport.height );

      this.setHorizontalScrollRange( 0, maxScrollX );
      this.setVerticalScrollRange( 0, maxScrollY );

      // Mouse-centered zoom coordinate mapping
      if ( oldW > 0 && oldH > 0 && newW > 0 && newH > 0 )
      {
         let cx = (cursorX !== undefined) ? cursorX : (this.viewport.width / 2);
         let cy = (cursorY !== undefined) ? cursorY : (this.viewport.height / 2);

         let fracX = (this.scrollPosition.x + cx) / oldW;
         let fracY = (this.scrollPosition.y + cy) / oldH;

         let newScrollX = Math.round( fracX * newW - cx );
         let newScrollY = Math.round( fracY * newH - cy );

         newScrollX = Math.max( 0, Math.min( maxScrollX, newScrollX ) );
         newScrollY = Math.max( 0, Math.min( maxScrollY, newScrollY ) );

         this.scrollPosition = new Point( newScrollX, newScrollY );
      }

      this.viewport.update();

      if ( this.parent && this.parent.overviewControl )
         this.parent.overviewControl.update();
   }

   initScrollBars()
   {
      let image = this.getImage();
      if ( image == null || image.width <= 0 || image.height <= 0 )
      {
         this.setHorizontalScrollRange( 0, 0 );
         this.setVerticalScrollRange( 0, 0 );
      }
      else
      {
         this.setHorizontalScrollRange( 0, Math.max( 0, image.width - this.viewport.width ) );
         this.setVerticalScrollRange( 0, Math.max( 0, image.height - this.viewport.height ) );
      }
      this.viewport.update();
   }
};

//---------------------------------------------------------
// Dialog
//---------------------------------------------------------
var StarReductionDialog = class extends Dialog
{
   constructor()
   {
      super();

      this.windowTitle = "MK Star Reduction";
      this.userResizable = true;

      this.uiStrength = 0.30;
      this.previewOriginalBaseImage = null;
      this.previewReducedBaseImage = null;

      this.windows = ImageWindow.windows;
      var viewIds = [];
      for ( var i = 0; i < this.windows.length; ++i ) {
         viewIds.push(this.windows[i].mainView.id);
      }

      //------------------------------------------------------
      // Custom Title Header
      //------------------------------------------------------
      this.titleLabel = new Label(this);
      this.titleLabel.text = "MK Star Reduction - Version 1.1";
      this.titleLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
      this.titleLabel.styleSheet = "QLabel { background-color: #1A365D; color: #FFFFFF; font-weight: bold; font-size: 12pt; padding: 6px; }";

      //------------------------------------------------------
      // Description & Copyright Box
      //------------------------------------------------------
      this.descBox = new TextBox(this);
      this.descBox.readOnly = true;
      this.descBox.text =
         "This script performs precise star reduction utilizing the Transfer Method. " +
         "It allows for an intuitive, live-previewed reduction with optional Scale Protection.\n\n" +
         "© Mohammed Khalifa (mhk.astro) - 2026";
      this.descBox.minHeight = 90;
      this.descBox.maxHeight = 90;
      this.descBox.styleSheet = "QTextEdit { background-color: #EAEAEA; color: #000000; }";

      //------------------------------------------------------
      // Instructions / Guide Box
      //------------------------------------------------------
      this.guideBox = new GroupBox(this);
      this.guideBox.title = "Instructions";
      this.guideBox.sizer = new VerticalSizer;
      this.guideBox.sizer.margin = 6;
      this.guideBox.sizer.spacing = 3;

      var guideLines = [
         "1. Select your image with stars and starless image.",
         "2. Choose your preferred Scale Protection (optional).",
         "3. Adjust Reduction Strength and click 'Refresh Preview' to update.",
         "4. Use 'Toggle Original/Reduced' or 'Split View' under Navigator to compare.",
         "5. Choose whether to replace target or create a new image.",
         "6. Apply."
      ];

      for (var i = 0; i < guideLines.length; ++i) {
         var guideText = new Label(this.guideBox);
         guideText.text = guideLines[i];
         this.guideBox.sizer.add(guideText);
      }

      //------------------------------------------------------
      // Comboboxes
      //------------------------------------------------------
      this.starsLabel = new Label(this);
      this.starsLabel.text = "Image with stars:";
      this.starsLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;
      this.starsLabel.minWidth = 110;

      this.starsCombo = new ComboBox(this);
      for ( var i = 0; i < viewIds.length; ++i )
         this.starsCombo.addItem( viewIds[i] );

      for ( let i = 0; i < viewIds.length; ++i ) {
          if ( viewIds[i].toLowerCase().indexOf("starless") === -1 ) {
              this.starsCombo.currentItem = i;
              break;
          }
      }
      this.starsCombo.onItemSelected = () => this.refreshPreview();

      this.starlessLabel = new Label(this);
      this.starlessLabel.text = "Starless image:";
      this.starlessLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;
      this.starlessLabel.minWidth = 110;

      this.starlessCombo = new ComboBox(this);
      for ( var i = 0; i < viewIds.length; ++i )
         this.starlessCombo.addItem( viewIds[i] );

      let starlessFound = false;
      for ( let i = 0; i < viewIds.length; ++i ) {
          if ( viewIds[i].toLowerCase().indexOf("starless") !== -1 ) {
              this.starlessCombo.currentItem = i;
              starlessFound = true;
              break;
          }
      }

      if (!starlessFound && viewIds.length > 1) {
          this.starlessCombo.currentItem = 1;
      }
      this.starlessCombo.onItemSelected = () => this.refreshPreview();

      //------------------------------------------------------
      // Protection Selection
      //------------------------------------------------------
      this.protectionLabel = new Label(this);
      this.protectionLabel.text = "Star Protection:";
      this.protectionLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;
      this.protectionLabel.minWidth = 110;

      this.protectionCombo = new ComboBox(this);
      this.protectionCombo.addItem("None");
      this.protectionCombo.addItem("Protect Large Stars");
      this.protectionCombo.addItem("Protect Small Stars");
      this.protectionCombo.currentItem = 0;
      this.protectionCombo.onItemSelected = () => this.refreshPreview();

      //------------------------------------------------------
      // Slider Controls
      //------------------------------------------------------
      this.sliderLabel = new Label(this);
      this.sliderLabel.text = "Reduction Strength:";
      this.sliderLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;
      this.sliderLabel.minWidth = 110;

      this.slider = new Slider(this);
      this.slider.minValue = 0;
      this.slider.maxValue = 90;
      this.slider.value = 30;

      this.valueEdit = new Edit(this);
      this.valueEdit.minWidth = 55;
      this.valueEdit.maxWidth = 55;
      this.valueEdit.text = format("%.2f", this.uiStrength);

      this.slider.onValueUpdated = v =>
      {
         this.uiStrength = v / 100.0;
         var newText = format("%.2f", this.uiStrength);
         if (this.valueEdit.text !== newText) {
             this.valueEdit.text = newText;
         }
      };

      this.valueEdit.onEditCompleted = () =>
      {
         var val = parseFloat(this.valueEdit.text);
         if (isNaN(val)) val = 0.0;
         else if (val < 0.0) val = 0.0;
         else if (val > 1.0) val = 1.0;

         this.uiStrength = val;
         this.valueEdit.text = format("%.2f", this.uiStrength);
         this.slider.value = Math.round(this.uiStrength * 100);
      };

      //------------------------------------------------------
      // Output Options Group
      //------------------------------------------------------
      this.outputGroupBox = new GroupBox(this);
      this.outputGroupBox.title = "Output Mode";
      this.outputGroupBox.sizer = new HorizontalSizer;
      this.outputGroupBox.sizer.margin = 6;
      this.outputGroupBox.sizer.spacing = 15;

      this.replaceCheckBox = new CheckBox(this.outputGroupBox);
      this.replaceCheckBox.text = "Replace target image";
      this.replaceCheckBox.checked = true;

      this.createNewCheckBox = new CheckBox(this.outputGroupBox);
      this.createNewCheckBox.text = "Create new image";
      this.createNewCheckBox.checked = false;

      this.replaceCheckBox.onCheck = checked => {
         if (checked) this.createNewCheckBox.checked = false;
         else if (!this.createNewCheckBox.checked) this.replaceCheckBox.checked = true;
      };

      this.createNewCheckBox.onCheck = checked => {
         if (checked) this.replaceCheckBox.checked = false;
         else if (!this.replaceCheckBox.checked) this.createNewCheckBox.checked = true;
      };

      this.outputGroupBox.sizer.add(this.replaceCheckBox);
      this.outputGroupBox.sizer.add(this.createNewCheckBox);

      //------------------------------------------------------
      // Preview Controls Group Box (Zoom + Refresh)
      //------------------------------------------------------
      this.previewGroupBox = new GroupBox( this );
      this.previewGroupBox.title = "Preview Controls";
      this.previewGroupBox.sizer = new HorizontalSizer;
      this.previewGroupBox.sizer.margin = 8;
      this.previewGroupBox.sizer.spacing = 6;

      this.zoomLabel = new Label( this.previewGroupBox );
      this.zoomLabel.text = "Zoom: ";
      this.zoomLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

      this.zoomComboBox = new ComboBox( this.previewGroupBox );
      this.zoomComboBox.addItem( "4:1" );
      this.zoomComboBox.addItem( "3:1" );
      this.zoomComboBox.addItem( "2:1" );
      this.zoomComboBox.addItem( "1:1" );
      this.zoomComboBox.addItem( "1:2" );
      this.zoomComboBox.addItem( "Fit to Preview" );
      this.zoomComboBox.currentItem = 5;
      this.zoomComboBox.minWidth = 100;
      this.zoomComboBox.onItemSelected = index =>
      {
         this.updatePreviewZoom();
      };

      this.previewRefreshButton = new PushButton( this.previewGroupBox );
      this.previewRefreshButton.text = "Refresh Preview";
      this.previewRefreshButton.minWidth = 110;
      this.previewRefreshButton.onClick = () =>
      {
         this.refreshPreview();
      };

      this.previewGroupBox.sizer.add( this.zoomLabel );
      this.previewGroupBox.sizer.add( this.zoomComboBox );
      this.previewGroupBox.sizer.addSpacing( 12 );
      this.previewGroupBox.sizer.add( this.previewRefreshButton );
      this.previewGroupBox.sizer.addStretch();

      //------------------------------------------------------
      // Action Buttons
      //------------------------------------------------------
      this.apply_Button = new PushButton(this);
      this.apply_Button.text = "Apply";
      this.apply_Button.defaultButton = true;
      this.apply_Button.onClick = () =>
      {
         var starsId = this.starsCombo.itemText(this.starsCombo.currentItem);
         var starlessId = this.starlessCombo.itemText(this.starlessCombo.currentItem);

         if (starsId === starlessId) {
             new MessageBox("The 'Stars' and 'Starless' image selections must be different.", "Error", StdIcon_Error, StdButton_Ok).execute();
             return;
         }

         var targetView = View.viewById(starsId);
         if (targetView.isNull) {
             new MessageBox("Could not locate the target image.", "Error", StdIcon_Error,StdButton_Ok).execute();
             return;
         }

         if (this.createNewCheckBox.checked) {
             let newWindowName = starsId + "_StarReduced";
             let newView = this.cloneView(targetView, newWindowName);

             Console.enabled = false;
             try {
                 this.applyReduction(newView, starlessId, this.uiStrength, this.protectionCombo.currentItem);
             } finally {
                 Console.enabled = true;
             }
             newView.window.show();
             newView.window.zoomToFit();
         } else {
             Console.enabled = false;
             try {
                 this.applyReduction(targetView, starlessId, this.uiStrength, this.protectionCombo.currentItem);
             } finally {
                 Console.enabled = true;
             }
         }
      };

      this.undo_Button = new PushButton(this);
      this.undo_Button.text = "Undo";
      this.undo_Button.toolTip = "This button works only when replacing target image.";
      this.undo_Button.onClick = () =>
      {
         var starsId = this.starsCombo.itemText(this.starsCombo.currentItem);
         var targetView = View.viewById(starsId);

         if (!targetView.isNull && targetView.window) {
             targetView.window.undo();
         }
      };

      this.close_Button = new PushButton(this);
      this.close_Button.text = "Close";
      this.close_Button.onClick = () =>
      {
         this.ok();
      };

      //------------------------------------------------------
      // Embedded Preview Component & Navigator
      //------------------------------------------------------
      this.previewLabelBar = new Label( this );
      this.previewLabelBar.text = "Split View (Original Left | Reduced Right)";
      this.previewLabelBar.textAlignment = TextAlign_Center | TextAlign_VertCenter;
      this.previewLabelBar.styleSheet = "QLabel { background-color: #2D3748; color: #FFFFFF; font-weight: bold; font-size: 10pt; padding: 4px; }";

      this.previewControl = new ScrollControl( this );
      this.previewControl.setMinWidth( 700 );
      this.previewControl.setMinHeight( 700 );

      this.overviewLabel = new Label( this );
      this.overviewLabel.text = "Navigator";
      this.overviewLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
      this.overviewLabel.styleSheet = "QLabel { font-weight: bold; font-size: 9pt; color: #333333; }";

      this.overviewControl = new OverviewControl( this );
      this.overviewControl.mainPreview = this.previewControl;

      this.mapInstructionsLabel = new Label( this );
      this.mapInstructionsLabel.text = "• Click/Drag mini-map to Jump/Pan";
      this.mapInstructionsLabel.wordWrapping = true;
      this.mapInstructionsLabel.setFixedWidth( 130 );
      this.mapInstructionsLabel.styleSheet = "QLabel { font-size: 8pt; color: #555555; }";

      this.togglePreviewButton = new PushButton( this );
      this.togglePreviewButton.text = "Toggle Original";
      this.togglePreviewButton.toolTip = "Toggle whole preview between Original (Before) and Reduced (After) stars.";
      this.togglePreviewButton.minWidth = 130;
      this.togglePreviewButton.onClick = () =>
      {
         if ( this.previewControl.viewMode === VIEW_MODE_ORIGINAL )
         {
            this.previewControl.setViewMode( VIEW_MODE_REDUCED );
            this.togglePreviewButton.text = "Toggle Original";
            this.previewLabelBar.text = "Reduced View (After Star Reduction)";
         }
         else
         {
            this.previewControl.setViewMode( VIEW_MODE_ORIGINAL );
            this.togglePreviewButton.text = "Toggle Reduced";
            this.previewLabelBar.text = "Original View (Before Star Reduction)";
         }
      };

      this.toggleInstructionsLabel = new Label( this );
      this.toggleInstructionsLabel.text = "• Switch full view\nBefore / After";
      this.toggleInstructionsLabel.wordWrapping = true;
      this.toggleInstructionsLabel.setFixedWidth( 130 );
      this.toggleInstructionsLabel.styleSheet = "QLabel { font-size: 8pt; color: #555555; }";

      this.splitViewButton = new PushButton( this );
      this.splitViewButton.text = "Split View";
      this.splitViewButton.toolTip = "Enable side-by-side draggable split line comparison.";
      this.splitViewButton.minWidth = 130;
      this.splitViewButton.onClick = () =>
      {
         this.previewControl.setViewMode( VIEW_MODE_SPLIT );
         this.togglePreviewButton.text = "Toggle Original";
         this.previewLabelBar.text = "Split View (Original Left | Reduced Right)";
      };

      this.splitInstructionsLabel = new Label( this );
      this.splitInstructionsLabel.text = "• Drag split handle\nto compare";
      this.splitInstructionsLabel.wordWrapping = true;
      this.splitInstructionsLabel.setFixedWidth( 130 );
      this.splitInstructionsLabel.styleSheet = "QLabel { font-size: 8pt; color: #555555; }";

      this.overviewSizer = new VerticalSizer;
      this.overviewSizer.spacing = 4;
      this.overviewSizer.add( this.overviewLabel );
      this.overviewSizer.add( this.overviewControl );
      this.overviewSizer.addSpacing( 4 );
      this.overviewSizer.add( this.mapInstructionsLabel );
      this.overviewSizer.addSpacing( 10 );
      this.overviewSizer.add( this.togglePreviewButton );
      this.overviewSizer.addSpacing( 4 );
      this.overviewSizer.add( this.toggleInstructionsLabel );
      this.overviewSizer.addSpacing( 10 );
      this.overviewSizer.add( this.splitViewButton );
      this.overviewSizer.addSpacing( 4 );
      this.overviewSizer.add( this.splitInstructionsLabel );
      this.overviewSizer.addStretch();

      this.previewSizer = new HorizontalSizer;
      this.previewSizer.spacing = 8;
      this.previewSizer.add( this.overviewSizer );
      this.previewSizer.add( this.previewControl, 100 );

      this.onPreviewWheelZoom = ( delta, x, y, modifiers ) =>
      {
         let i = this.zoomComboBox.currentItem;

         if ( delta > 0 )
            i = Math.max( 0, i - 1 );
         else if ( delta < 0 )
            i = Math.min( this.zoomComboBox.numberOfItems - 1, i + 1 );

         if ( i != this.zoomComboBox.currentItem )
         {
            this.zoomComboBox.currentItem = i;
            this.updatePreviewZoom( x, y );
         }
      };

      this.rightSizer = new VerticalSizer;
      this.rightSizer.margin = 0;
      this.rightSizer.spacing = 4;
      this.rightSizer.add( this.previewLabelBar );
      this.rightSizer.add( this.previewSizer );

      //------------------------------------------------------
      // Layout Initialization
      //------------------------------------------------------
      var starsSizer = new HorizontalSizer;
      starsSizer.spacing = 6;
      starsSizer.add(this.starsLabel);
      starsSizer.add(this.starsCombo, 100);

      var starSizer = new HorizontalSizer;
      starSizer.spacing = 6;
      starSizer.add(this.starlessLabel);
      starSizer.add(this.starlessCombo, 100);

      var protSizer = new HorizontalSizer;
      protSizer.spacing = 6;
      protSizer.add(this.protectionLabel);
      protSizer.add(this.protectionCombo, 100);

      var sliderSizer = new HorizontalSizer;
      sliderSizer.spacing = 6;
      sliderSizer.add(this.sliderLabel);
      sliderSizer.add(this.slider, 100);
      sliderSizer.add(this.valueEdit);

      var buttonSizer = new HorizontalSizer;
      buttonSizer.add(this.apply_Button);
      buttonSizer.addSpacing(6);
      buttonSizer.add(this.undo_Button);
      buttonSizer.addSpacing(6);
      buttonSizer.add(this.close_Button);
      buttonSizer.addStretch();

      this.leftSizer = new VerticalSizer;
      this.leftSizer.margin = 12;
      this.leftSizer.spacing = 8;

      this.leftSizer.add(this.titleLabel);
      this.leftSizer.addSpacing(4);
      this.leftSizer.add(this.descBox);
      this.leftSizer.addSpacing(8);

      this.leftSizer.add(this.guideBox);
      this.leftSizer.addSpacing(4);
      this.leftSizer.add(starsSizer);
      this.leftSizer.add(starSizer);
      this.leftSizer.addSpacing(6);
      this.leftSizer.add(protSizer);
      this.leftSizer.addSpacing(6);
      this.leftSizer.add(sliderSizer);
      this.leftSizer.addSpacing(6);
      this.leftSizer.add(this.outputGroupBox);
      this.leftSizer.addSpacing(6);
      this.leftSizer.add(this.previewGroupBox);
      this.leftSizer.addSpacing(6);
      this.leftSizer.add(buttonSizer);
      this.leftSizer.addStretch();
      this.leftSizer.minWidth = 550;

      this.mainSizer = new HorizontalSizer;
      this.mainSizer.margin = 8;
      this.mainSizer.spacing = 8;
      this.mainSizer.add( this.leftSizer );
      this.mainSizer.add( this.rightSizer );

      this.sizer = this.mainSizer;

      this.adjustToContents();
      this.setFixedSize();

      this.refreshPreview();
   }

   //------------------------------------------------------
   // Clone View Helper
   //------------------------------------------------------
   cloneView(view, newId)
   {
      let win = new ImageWindow(
         view.image.width,
         view.image.height,
         view.image.numberOfChannels,
         view.image.bitsPerSample,
         view.image.isReal,
         view.image.isColor,
         newId
      );
      win.mainView.beginProcess();
      win.mainView.image.assign(view.image);
      win.mainView.endProcess();
      return win.mainView;
   }

   //------------------------------------------------------
   // Mask Generation Logic
   //------------------------------------------------------
   createStarMask(targetView, starlessId)
   {
      let maskId = "tmp_mask_" + Math.random().toString(36).substring(7);
      let tempId = "tmp_temp_" + Math.random().toString(36).substring(7);

      var P = new PixelMath;
      P.expression = "Img1 = " + starlessId + ";\n\n";

      if (targetView.image.isColor) {
         P.expression += "E1= ($T[0]+$T[1]+$T[2])/3;\n" +
                         "E2= (Img1[0]+Img1[1]+Img1[2])/3;\n";
      } else {
         P.expression += "E1= $T;\n" +
                         "E2= Img1;\n";
      }

      P.expression += "E3= rescale(E1,-0.001,1.001);\n" +
                      "E4= rescale(E2,-0.001,1.001);\n" +
                      "n= E3 - E4;\n" +
                      "d= E3*(~E4);\n" +
                      "n/d;";

      P.symbols = "Img1,E1,E2,E3,E4,n,d";
      P.createNewImage = true;
      P.showNewImage = false;
      P.newImageId = maskId;
      P.executeOn(targetView);

      let maskView = View.viewById(maskId);
      let tempView = this.cloneView(maskView, tempId);

      P.createNewImage = false;
      P.newImageId = "";
      P.symbols = "";

      P.expression = "rescale(medfilt($T,11,str_circular() ),0,.95);";
      P.executeOn(tempView);

      P.expression = "rescale(mtf(0.3,$T - " + tempId + "),0,.75);";
      P.executeOn(maskView);

      P.expression = "mean($T,dilation($T,3,str_circular()));";
      P.executeOn(maskView);

      P.expression = "~bconv($T,3);";
      P.executeOn(maskView);

      tempView.window.forceClose();

      return maskView.window;
   }

   //------------------------------------------------------
   // Unified Processing Function
   //------------------------------------------------------
   applyReduction(targetView, starlessId, strength, protectionIndex)
   {
      var PM = new PixelMath;
      PM.useSingleExpression = true;
      PM.createNewImage = false;
      PM.truncate = true;
      PM.truncateLower = 0;
      PM.truncateUpper = 1;

      let mathStrength = 0.51 - (strength * 0.51);

      PM.expression = "Img1 = " + starlessId + ";\n" +
                      "S = " + mathStrength.toFixed(2) + ";\n" +
                      "~((~mtf(~S,$T)/~mtf(~S,Img1))*~Img1);";
      PM.symbols = "S,Img1";

      // Handle Mask Protection Injection
      let maskWin = null;
      if (protectionIndex > 0) {
         maskWin = this.createStarMask(targetView, starlessId);
         targetView.window.mask = maskWin;
         targetView.window.maskEnabled = true;
         // 1 = Protect Large Stars (Invert to block small stars, reduce large stars)
         // 2 = Protect Small Stars (Normal to reduce small stars, block large stars)
         targetView.window.maskInverted = (protectionIndex === 1);
         targetView.window.maskVisible = false;
      }

      PM.executeOn(targetView);

      // Clean up mask workspace
      if (maskWin) {
         targetView.window.maskEnabled = false;
         targetView.window.removeMask();
         maskWin.forceClose();
      }
   }

   //------------------------------------------------------
   // Preview Core Logic Functions
   //------------------------------------------------------
   refreshPreview()
   {
      var starsId = this.starsCombo.itemText(this.starsCombo.currentItem);
      var starlessId = this.starlessCombo.itemText(this.starlessCombo.currentItem);

      if (starsId === starlessId || !starsId || !starlessId) return;

      this.buildPreviewBaseImage(starsId, starlessId);
      this.updatePreviewZoom();
   }

   buildPreviewBaseImage(starsId, starlessId)
   {
      let targetView = View.viewById(starsId);
      let starlessView = View.viewById(starlessId);
      if (targetView.isNull || starlessView.isNull) return;

      let window = this.cloneView(targetView, "tmp_preview_" + Math.random().toString(36).substring(7));

      // 1. Store Original Base Image
      this.previewOriginalBaseImage = new Image( targetView.image );

      // 2. Process the Reduced Base Image Safely
      Console.enabled = false;
      try {
         this.applyReduction( window, starlessId, this.uiStrength, this.protectionCombo.currentItem );
      } finally {
         Console.enabled = true;
      }

      this.previewReducedBaseImage = new Image( window.image );
      window.window.forceClose();

      // Update Navigator Thumbnail
      this.overviewControl.doUpdateThumbnail( this.previewReducedBaseImage );
   }

   updatePreviewZoom( cursorX, cursorY )
   {
      if ( this.previewOriginalBaseImage == null || this.previewReducedBaseImage == null ) return;

      let resampleImage = ( img, zoomIndex ) =>
      {
         let window = new ImageWindow(
            img.width,
            img.height,
            img.numberOfChannels,
            img.bitsPerSample,
            img.isReal,
            img.isColor
         );

         window.mainView.beginProcess();
         window.mainView.image.assign( img );
         window.mainView.endProcess();

         let P = new IntegerResample;

         switch ( zoomIndex )
         {
         case 0: P.zoomFactor = 4; break;
         case 1: P.zoomFactor = 3; break;
         case 2: P.zoomFactor = 2; break;
         case 3: P.zoomFactor = 1; break;
         case 4: P.zoomFactor = -2; break;
         case 5: // Fit to Preview
            {
               let previewWidth = Math.max( this.previewControl.width, 1 );
               let widthScale = Math.floor( img.width / previewWidth );
               P.zoomFactor = -Math.max( widthScale, 1 );
            }
            break;
         default: P.zoomFactor = 1; break;
         }

         P.executeOn( window.mainView );

         let resized = new Image( window.mainView.image );
         window.forceClose();
         return resized;
      };

      let resizedOrig = resampleImage( this.previewOriginalBaseImage, this.zoomComboBox.currentItem );
      let resizedRed = resampleImage( this.previewReducedBaseImage, this.zoomComboBox.currentItem );

      this.previewControl.doUpdateImages( resizedOrig, resizedRed, cursorX, cursorY );
   }
};

//---------------------------------------------------------
// Main
//---------------------------------------------------------
function main()
{
   if ( ImageWindow.windows.length < 2 )
   {
      new MessageBox(
         "You need to have at least two images open (a star image and a starless image).",
         "Error",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return;
   }

   var dlg = new StarReductionDialog();
   dlg.execute();
}

main();

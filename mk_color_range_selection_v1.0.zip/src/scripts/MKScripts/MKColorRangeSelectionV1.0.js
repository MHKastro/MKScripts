#engine v8

#feature-id    MK Scripts > Color Range Selection
#feature-info  Interactive Color Range Mask Generation mimicking Photoshop's feature.
#feature-icon  color_range.svg

#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>

//---------------------------------------------------------
// OverviewControl Class (Mini-Map Navigator)
//---------------------------------------------------------
var OverviewControl = class extends Control
{
   constructor( parent )
   {
      super( parent );
      this.bmpThumbnail = null;
      this.mainPreview = null;
      this.imageWidth = 0;
      this.imageHeight = 0;

      this.setMinSize( 150, 150 );
      this.setMaxSize( 150, 150 );

      this.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let g = new Graphics( this );
         g.fillRect( x0, y0, x1, y1, new Brush( 0xff151515 ) );

         if ( this.bmpThumbnail && this.imageWidth > 0 && this.imageHeight > 0 && this.mainPreview )
         {
            let boxW = this.width;
            let boxH = this.height;
            let scale = Math.min( boxW / this.imageWidth, boxH / this.imageHeight );
            let drawW = Math.round( this.imageWidth * scale );
            let drawH = Math.round( this.imageHeight * scale );

            let offsetX = Math.round( (boxW - drawW) / 2 );
            let offsetY = Math.round( (boxH - drawH) / 2 );

            g.drawBitmap( offsetX, offsetY, this.bmpThumbnail );

            let mainBmp = this.mainPreview.bmp;
            if ( mainBmp && mainBmp.width > 0 && mainBmp.height > 0 )
            {
               let viewW = this.mainPreview.viewport.width;
               let viewH = this.mainPreview.viewport.height;
               let scrollX = this.mainPreview.scrollPosition.x;
               let scrollY = this.mainPreview.scrollPosition.y;

               let fracX = scrollX / mainBmp.width;
               let fracY = scrollY / mainBmp.height;
               let fracW = Math.min( 1.0, viewW / mainBmp.width );
               let fracH = Math.min( 1.0, viewH / mainBmp.height );

               let rectX = offsetX + Math.round( fracX * drawW );
               let rectY = offsetY + Math.round( fracY * drawH );
               let rectW = Math.max( 6, Math.round( fracW * drawW ) );
               let rectH = Math.max( 6, Math.round( fracH * drawH ) );

               rectX = Math.max( offsetX, Math.min( offsetX + drawW - rectW, rectX ) );
               rectY = Math.max( offsetY, Math.min( offsetY + drawH - rectH, rectY ) );

               g.fillRect( rectX, rectY, rectX + rectW, rectY + rectH, new Brush( 0x33ff0000 ) );
               g.pen = new Pen( 0xffff0000, 1.5 );
               g.drawRect( rectX, rectY, rectX + rectW, rectY + rectH );
            }

            g.pen = new Pen( 0xff444444, 1 );
            g.drawRect( 0, 0, boxW, boxH );
         }
         g.end();
      };

      this.onMousePress = ( x, y ) => { this.centerScrollAt( x, y ); };
      this.onMouseMove = ( x, y, buttons ) => { if ( buttons === 1 ) this.centerScrollAt( x, y ); };
   }

   centerScrollAt( x, y )
   {
      if ( !this.bmpThumbnail || !this.mainPreview || this.imageWidth <= 0 || this.imageHeight <= 0 ) return;
      let mainBmp = this.mainPreview.bmp;
      if ( !mainBmp || mainBmp.width <= 0 || mainBmp.height <= 0 ) return;

      let boxW = this.width;
      let boxH = this.height;
      let scale = Math.min( boxW / this.imageWidth, boxH / this.imageHeight );
      let drawW = Math.round( this.imageWidth * scale );
      let drawH = Math.round( this.imageHeight * scale );

      let offsetX = Math.round( (boxW - drawW) / 2 );
      let offsetY = Math.round( (boxH - drawH) / 2 );

      let relX = Math.max( 0, Math.min( 1.0, (x - offsetX) / Math.max( 1, drawW ) ) );
      let relY = Math.max( 0, Math.min( 1.0, (y - offsetY) / Math.max( 1, drawH ) ) );

      let viewW = this.mainPreview.viewport.width;
      let viewH = this.mainPreview.viewport.height;

      let targetScrollX = Math.round( relX * mainBmp.width - viewW / 2 );
      let targetScrollY = Math.round( relY * mainBmp.height - viewH / 2 );

      let maxScrollX = Math.max(0, mainBmp.width - viewW);
      let maxScrollY = Math.max(0, mainBmp.height - viewH);

      targetScrollX = Math.max( 0, Math.min( maxScrollX, targetScrollX ) );
      targetScrollY = Math.max( 0, Math.min( maxScrollY, targetScrollY ) );

      this.mainPreview.scrollPosition = new Point( targetScrollX, targetScrollY );
      this.mainPreview.viewport.update();

      if (this.mainPreview.syncControl && this.parent && this.parent.syncCheckBox.checked) {
         this.mainPreview.syncControl.scrollPosition = new Point( targetScrollX, targetScrollY );
         this.mainPreview.syncControl.viewport.update();
      }
      this.update();
   }

   doUpdateThumbnail( baseImage )
   {
      if ( !baseImage ) return;
      this.imageWidth = baseImage.width;
      this.imageHeight = baseImage.height;

      let boxW = this.width;
      let boxH = this.height;
      let scale = Math.max( Math.floor( baseImage.width / boxW ), Math.floor( baseImage.height / boxH ) );

      let window = new ImageWindow( baseImage.width, baseImage.height, baseImage.numberOfChannels, baseImage.bitsPerSample, baseImage.isReal, baseImage.isColor );
      window.mainView.beginProcess();
      window.mainView.image.assign( baseImage );
      window.mainView.endProcess();

      let P = new IntegerResample;
      P.zoomFactor = -Math.max( 1, scale );
      P.executeOn( window.mainView );

      let thumbImage = new Image( window.mainView.image );
      window.forceClose();

      this.bmpThumbnail = thumbImage.render();
      this.update();
   }
};

//---------------------------------------------------------
// ImagePreviewControl Class (Handles Zoom, Pan, and Click-to-Pick)
//---------------------------------------------------------
var ImagePreviewControl = class extends ScrollBox
{
   constructor( parent, isInput )
   {
      super( parent );
      this.isInput = isInput;
      this.bmp = null;
      this.originalImg = null;
      this.zoomIndex = 9;

      this.syncControl = null;
      this.isSyncing = false;

      this.dragging = false;
      this.dragOrigin = new Point( 0, 0 );
      this.mouseButton = 0;

      this.activeCursor = this.createCustomCursor( 0 );
      this.viewport.cursor = this.activeCursor;

      this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let g = new Graphics( this.viewport );
         g.fillRect( x0, y0, x1, y1, new Brush( 0xff151515 ) );

         if ( this.bmp != null )
            g.drawBitmap( -this.scrollPosition.x, -this.scrollPosition.y, this.bmp );
         g.end();
      };

      this.onHorizontalScrollPosUpdated = x =>
      {
         this.viewport.update();
         if ( this.syncControl && this.parentDialog && this.parentDialog.syncCheckBox.checked && !this.isSyncing )
         {
            this.isSyncing = true;
            this.syncControl.scrollPosition = new Point( x, this.syncControl.scrollPosition.y );
            this.syncControl.viewport.update();
            this.isSyncing = false;
         }
         if (this.parentDialog && this.parentDialog.overviewControl) this.parentDialog.overviewControl.update();
      };

      this.onVerticalScrollPosUpdated = y =>
      {
         this.viewport.update();
         if ( this.syncControl && this.parentDialog && this.parentDialog.syncCheckBox.checked && !this.isSyncing )
         {
            this.isSyncing = true;
            this.syncControl.scrollPosition = new Point( this.syncControl.scrollPosition.x, y );
            this.syncControl.viewport.update();
            this.isSyncing = false;
         }
         if (this.parentDialog && this.parentDialog.overviewControl) this.parentDialog.overviewControl.update();
      };

      this.viewport.onMouseWheel = ( x, y, delta, button, modifiers ) =>
      {
         if ( this.parentDialog ) this.parentDialog.handleWheelZoom( this, delta, x, y );
      };

      this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
      {
         this.dragOrigin = new Point( x, y );
         this.dragging = false;
         this.mouseButton = button;
         if ( button === 2 || button === 4 ) this.viewport.cursor = new Cursor( StdCursor_ClosedHand );
      };

      this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
      {
         if ( this.mouseButton === 2 || this.mouseButton === 4 )
         {
            if ( Math.abs(x - this.dragOrigin.x) > 2 || Math.abs(y - this.dragOrigin.y) > 2 )
               this.dragging = true;

            if ( this.dragging )
            {
               let dx = this.dragOrigin.x - x;
               let dy = this.dragOrigin.y - y;
               this.scrollPosition = new Point( this.scrollPosition.x + dx, this.scrollPosition.y + dy );
               this.dragOrigin = new Point( x, y );
            }
         }
      };

      this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
      {
         if ( this.isInput && button === 1 )
         {
            let ratioX = this.originalImg.width / this.bmp.width;
            let mappedX = Math.round( (x + this.scrollPosition.x) * ratioX );
            let mappedY = Math.round( (y + this.scrollPosition.y) * ratioX );
            if ( this.parentDialog ) this.parentDialog.onColorPickedXY( mappedX, mappedY );
         }
         this.mouseButton = 0;
         this.dragging = false;
         this.viewport.cursor = this.activeCursor;
      };
   }

   setCursorStyle( styleIndex )
   {
      this.activeCursor = this.createCustomCursor( styleIndex );
      this.viewport.cursor = this.activeCursor;
   }

   createCustomCursor( typeIndex )
   {
      switch ( typeIndex )
      {
         case 0: return new Cursor( StdCursor_Arrow );
         case 1: return new Cursor( StdCursor_Crossmark );
         case 2:
            {
               let cursorBmp = new Bitmap( 17, 17 );
               cursorBmp.fill( 0x00000000 );
               let g = new Graphics( cursorBmp );
               g.antialiasing = true;
               g.pen = new Pen( 0xffffffff, 1 );
               g.drawEllipse( 1, 1, 15, 15 );
               g.pen = new Pen( 0xff000000, 1 );
               g.drawEllipse( 2, 2, 13, 13 );
               g.pen = new Pen( 0xffff0000, 1.5 );
               g.drawPoint( 8, 8 );
               g.end();
               return new Cursor( cursorBmp, 8, 8 );
            }
         case 3:
            {
               let cursorBmp = new Bitmap( 11, 11 );
               cursorBmp.fill( 0x00000000 );
               let g = new Graphics( cursorBmp );
               g.antialiasing = true;
               g.pen = new Pen( 0xff000000, 1 );
               g.brush = new Brush( 0xffff0000 );
               g.drawEllipse( 3, 3, 5, 5 );
               g.end();
               return new Cursor( cursorBmp, 5, 5 );
            }
         case 4:
            {
               let cursorBmp = new Bitmap( 21, 21 );
               cursorBmp.fill( 0x00000000 );
               let g = new Graphics( cursorBmp );
               g.antialiasing = false;
               g.pen = new Pen( 0xffffffff, 1 );
               g.drawLine( 0, 10, 6, 10 );
               g.drawLine( 14, 10, 20, 10 );
               g.drawLine( 10, 0, 10, 6 );
               g.drawLine( 10, 14, 10, 20 );
               g.antialiasing = true;
               g.pen = new Pen( 0xffff0000, 1 );
               g.drawEllipse( 7, 7, 7, 7 );
               g.end();
               return new Cursor( cursorBmp, 10, 10 );
            }
         default: return new Cursor( StdCursor_Arrow );
      }
   }

   updateImage( img, originalRef, cursorX, cursorY )
   {
      let oldW = this.bmp ? this.bmp.width : 0;
      let oldH = this.bmp ? this.bmp.height : 0;
      let oldScrollX = this.scrollPosition.x;
      let oldScrollY = this.scrollPosition.y;

      this.originalImg = originalRef;

      if ( !img )
      {
         this.bmp = null;
         this.setHorizontalScrollRange( 0, 0 );
         this.setVerticalScrollRange( 0, 0 );
      }
      else
      {
         this.bmp = img.render();
         let newW = this.bmp.width;
         let newH = this.bmp.height;

         let maxScrollX = Math.max( 0, newW - this.viewport.width );
         let maxScrollY = Math.max( 0, newH - this.viewport.height );

         this.setHorizontalScrollRange( 0, maxScrollX );
         this.setVerticalScrollRange( 0, maxScrollY );

         if ( oldW > 0 && oldH > 0 && newW > 0 && newH > 0 && cursorX !== undefined && cursorY !== undefined )
         {
            let scaleRatioX = newW / oldW;
            let scaleRatioY = newH / oldH;

            let pixelX = oldScrollX + cursorX;
            let pixelY = oldScrollY + cursorY;

            let newPixelX = pixelX * scaleRatioX;
            let newPixelY = pixelY * scaleRatioY;

            let newScrollX = Math.round( newPixelX - cursorX );
            let newScrollY = Math.round( newPixelY - cursorY );

            this.scrollPosition = new Point(
               Math.max( 0, Math.min( maxScrollX, newScrollX ) ),
               Math.max( 0, Math.min( maxScrollY, newScrollY ) )
            );
         }
      }
      this.viewport.update();
      if (this.parentDialog && this.parentDialog.overviewControl) this.parentDialog.overviewControl.update();
   }
};

//---------------------------------------------------------
// Color Patch Control (Multi-Color Array Visualizer)
//---------------------------------------------------------
var ColorPatch = class extends Control
{
   constructor( parent )
   {
      super( parent );
      this.setMinSize( 45, 22 );
      this.setMaxSize( 45, 22 );
      this.colors = [];
      this.toolTip = "Shows the exact physical color(s) currently sampled in your mask pool.";

      this.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let g = new Graphics( this );
         g.fillRect( x0, y0, x1, y1, new Brush( 0xff151515 ) );

         if (this.colors.length === 0) {
            g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
         } else {
            let stripWidth = (x1 - x0) / this.colors.length;
            for (let i = 0; i < this.colors.length; i++) {
               let c = this.colors[i];
               let r8 = Math.round( c.r * 255 );
               let g8 = Math.round( c.g * 255 );
               let b8 = Math.round( c.b * 255 );
               let color = 0xff000000 | (r8 << 16) | (g8 << 8) | b8;
               g.fillRect( x0 + (i * stripWidth), y0, x0 + ((i + 1) * stripWidth), y1, new Brush( color ) );
            }
         }

         g.pen = new Pen( 0xffffffff, 1 );
         g.drawRect( x0, y0, x1, y1 );
         g.end();
      };
   }

   setColors( colorsArray )
   {
      this.colors = colorsArray;
      this.update();
   }
};

//---------------------------------------------------------
// Main Dialog
//---------------------------------------------------------
var ColorRangeDialog = class extends Dialog
{
   constructor()
   {
      super();

      this.windowTitle = "Color Range Selection";
      this.userResizable = true;
      this.setMinSize( 1800, 750 );

      this.sampledColors = [];

      this.fuzziness = 0.20;
      this.blurRadius = 0.0;
      this.maskOpacity = 1.0;
      this.debounceDelay = 0.40; // Default 0.40s delay as requested
      this.isProgrammaticZoomUpdate = false;

      this.srcWin = null;
      this.maskWin = null;

      this.updateTimer = new Timer();
      this.updateTimer.interval = this.debounceDelay;
      this.updateTimer.periodic = false;
      this.updateTimer.onTimeout = () => { this.refreshMask(); };

      this.onReturn = () => this.cleanUp();

      this.buildUI();
      this.updateTargetImage();
   }

   triggerUpdate()
   {
      if ( this.debounceDelay <= 0.001 )
      {
         this.updateTimer.stop();
         this.refreshMask();
      }
      else
      {
         this.updateTimer.interval = this.debounceDelay;
         this.updateTimer.start();
      }
   }

   buildUI()
   {
      let windows = ImageWindow.windows;
      let viewIds = windows.map( w => w.mainView.id );

      // ---- Top Title & Copyright Header ----
      this.titleLabel = new Label( this );
      this.titleLabel.text = "Color Range Selection (Mask Generator) V1.0\n© Mohammed Khalifa (mhk.astro) - 2026";
      this.titleLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
      this.titleLabel.styleSheet = "QLabel { background-color: #1A365D; color: #FFFFFF; font-weight: bold; font-size: 9pt; padding: 6px; }";

      // ---- Instructions Box ----
      this.instructionsBox = new GroupBox( this );
      this.instructionsBox.title = "Instructions";

      let instructionsText = new Label( this.instructionsBox );
      instructionsText.text =
         "1. Click on the source image to pick sample colors.\n" +
         "2. Use 'Multiple Selection (Additive)' to combine different color regions.\n" +
         "3. Right-click & drag to pan. Scroll wheel to zoom previews.\n" +
         "4. Adjust fuzziness, blur, and opacity to refine the mask.\n" +
         "5. Click 'Create Mask' to output your final mask.";

      let instSizer = new VerticalSizer;
      instSizer.margin = 6;
      instSizer.add( instructionsText );
      this.instructionsBox.sizer = instSizer;

      // ---- Target Image Selection ----
      this.imageLabel = new Label( this );
      this.imageLabel.text = "Target Image:";
      this.imageLabel.minWidth = 110;

      this.imageCombo = new ComboBox( this );
      viewIds.forEach( id => this.imageCombo.addItem( id ) );
      this.imageCombo.toolTip = "Select the target image window to generate the mask from.";
      this.imageCombo.onItemSelected = () => this.updateTargetImage();

      let imgSizer = new HorizontalSizer;
      imgSizer.spacing = 6;
      imgSizer.add( this.imageLabel );
      imgSizer.add( this.imageCombo, 100 );

      // ---- Checkboxes ----
      this.linearImage_Cb = new CheckBox( this );
      this.linearImage_Cb.text = "Linear Image (Auto Stretch)";
      this.linearImage_Cb.toolTip = "Automatically applies a temporary ScreenTransferFunction so you can easily see and click colors on linear data.";
      this.linearImage_Cb.checked = false;
      this.linearImage_Cb.onCheck = () => { this.updateTargetImage(); };

      this.invertMask_Cb = new CheckBox( this );
      this.invertMask_Cb.text = "Invert Mask";
      this.invertMask_Cb.toolTip = "Inverts the final mask calculation, making selected colors black and unselected regions white.";
      this.invertMask_Cb.checked = false;
      this.invertMask_Cb.onCheck = () => { this.triggerUpdate(); };

      this.multiSelect_Cb = new CheckBox( this );
      this.multiSelect_Cb.text = "Multiple Selection (Additive)";
      this.multiSelect_Cb.toolTip = "When checked, each new click will add to the existing mask instead of replacing it.";
      this.multiSelect_Cb.checked = false;

      let checksSizer = new HorizontalSizer;
      checksSizer.spacing = 6;
      checksSizer.addSpacing( 116 );

      let vChecks = new VerticalSizer;
      vChecks.spacing = 4;
      vChecks.add( this.linearImage_Cb );
      vChecks.add( this.invertMask_Cb );
      vChecks.add( this.multiSelect_Cb );
      checksSizer.add( vChecks, 100 );

      // ---- Sampling Area Size ----
      this.sampleSizeLabel = new Label( this );
      this.sampleSizeLabel.text = "Sample Size:";
      this.sampleSizeLabel.minWidth = 110;

      this.sampleSizeCombo = new ComboBox( this );
      this.sampleSizeCombo.addItem( "Point (1x1)" );
      this.sampleSizeCombo.addItem( "Average (3x3)" );
      this.sampleSizeCombo.addItem( "Average (5x5)" );
      this.sampleSizeCombo.currentItem = 0;
      this.sampleSizeCombo.toolTip = "Increase sample size to average out random noise or grain when picking colors.";

      let sampleSizeSizer = new HorizontalSizer;
      sampleSizeSizer.spacing = 6;
      sampleSizeSizer.add( this.sampleSizeLabel );
      sampleSizeSizer.add( this.sampleSizeCombo, 100 );

      // ---- Cursor Options ----
      this.cursorLabel = new Label( this );
      this.cursorLabel.text = "Cursor Style:";
      this.cursorLabel.minWidth = 110;

      this.cursorCombo = new ComboBox( this );
      this.cursorCombo.addItem( "Arrow" );
      this.cursorCombo.addItem( "Crosshair" );
      this.cursorCombo.addItem( "Target Circle" );
      this.cursorCombo.addItem( "Small Red Dot" );
      this.cursorCombo.addItem( "Precision Reticle" );
      this.cursorCombo.currentItem = 0;
      this.cursorCombo.toolTip = "Select your preferred mouse cursor pointer style for sampling colors.";
      this.cursorCombo.onItemSelected = index => {
         this.inputPreview.setCursorStyle( index );
         this.maskPreview.setCursorStyle( index );
      };

      let cursorSizer = new HorizontalSizer;
      cursorSizer.spacing = 6;
      cursorSizer.add( this.cursorLabel );
      cursorSizer.add( this.cursorCombo, 100 );

      // ---- Color Readout & Undo ----
      this.colorLabel = new Label( this );
      this.colorLabel.text = "Sampled Color:";
      this.colorLabel.minWidth = 110;

      this.colorPatch = new ColorPatch( this );

      this.colorValues = new Label( this );
      this.colorValues.text = "R: 0.00  G: 0.00  B: 0.00";

      this.undo_Btn = new PushButton( this );
      this.undo_Btn.text = "Undo Last";
      this.undo_Btn.toolTip = "Remove the last sampled color from your mask selection pool.";
      this.undo_Btn.onClick = () => {
         if (this.sampledColors.length > 0) {
            this.sampledColors.pop();
            this.updateColorDisplays();
            this.refreshMask();
         }
      };

      let colorSizer = new HorizontalSizer;
      colorSizer.spacing = 6;
      colorSizer.add( this.colorLabel );
      colorSizer.add( this.colorPatch );
      colorSizer.addSpacing( 10 );
      colorSizer.add( this.colorValues, 100 );
      colorSizer.add( this.undo_Btn );

      // ---- Uniform Sizer Width Constants for Sliders ----
      const SLIDER_LABEL_WIDTH = 110;
      const EDIT_WIDTH = 45;

      // ---- Tolerance Slider ----
      this.fuzzLabel = new Label( this );
      this.fuzzLabel.text = "Tolerance:";
      this.fuzzLabel.minWidth = SLIDER_LABEL_WIDTH;

      this.fuzzSlider = new Slider( this );
      this.fuzzSlider.minValue = 1;
      this.fuzzSlider.maxValue = 100;
      this.fuzzSlider.value = Math.round( this.fuzziness * 100 );
      this.fuzzSlider.toolTip = "Controls color selection sensitivity. Higher values select a broader range of similar colors.";

      this.fuzzValue = new Edit( this );
      this.fuzzValue.text = this.fuzzSlider.value.toString();
      this.fuzzValue.setFixedWidth( EDIT_WIDTH );

      this.fuzzSlider.onValueUpdated = v => {
         this.fuzziness = v / 100.0;
         this.fuzzValue.text = v.toString();
         this.triggerUpdate();
      };

      this.fuzzValue.onEditCompleted = () => {
         let val = parseInt( this.fuzzValue.text );
         if ( isNaN( val ) ) val = 20;
         val = Math.max( 1, Math.min( 100, val ) );
         this.fuzziness = val / 100.0;
         this.fuzzValue.text = val.toString();
         this.fuzzSlider.value = val;
         this.triggerUpdate();
      };

      let fuzzSizer = new HorizontalSizer;
      fuzzSizer.spacing = 6;
      fuzzSizer.add( this.fuzzLabel );
      fuzzSizer.add( this.fuzzSlider, 100 );
      fuzzSizer.add( this.fuzzValue );

      // ---- Mask Blur Slider ----
      this.blurLabel = new Label( this );
      this.blurLabel.text = "Mask Blur:";
      this.blurLabel.minWidth = SLIDER_LABEL_WIDTH;

      this.blurSlider = new Slider( this );
      this.blurSlider.minValue = 0;
      this.blurSlider.maxValue = 100;
      this.blurSlider.value = this.blurRadius;
      this.blurSlider.toolTip = "Applies a Gaussian blur (Convolution) up to 100 pixels to soften the edges of the generated mask.";

      this.blurValue = new Edit( this );
      this.blurValue.text = this.blurRadius.toFixed( 1 );
      this.blurValue.setFixedWidth( EDIT_WIDTH );

      this.blurSlider.onValueUpdated = v => {
         this.blurRadius = v;
         this.blurValue.text = this.blurRadius.toFixed( 1 );
         this.triggerUpdate();
      };

      this.blurValue.onEditCompleted = () => {
         let val = parseFloat( this.blurValue.text );
         if ( isNaN( val ) ) val = 0.0;
         val = Math.max( 0.0, Math.min( 100.0, val ) );
         this.blurRadius = val;
         this.blurValue.text = val.toFixed( 1 );
         this.blurSlider.value = Math.round( val );
         this.triggerUpdate();
      };

      let blurSizer = new HorizontalSizer;
      blurSizer.spacing = 6;
      blurSizer.add( this.blurLabel );
      blurSizer.add( this.blurSlider, 100 );
      blurSizer.add( this.blurValue );

      // ---- Mask Opacity Slider (0% to 100%) ----
      this.opacityLabel = new Label( this );
      this.opacityLabel.text = "Mask Opacity:";
      this.opacityLabel.minWidth = SLIDER_LABEL_WIDTH;

      this.opacitySlider = new Slider( this );
      this.opacitySlider.minValue = 0;
      this.opacitySlider.maxValue = 100;
      this.opacitySlider.value = Math.round( this.maskOpacity * 100 );
      this.opacitySlider.toolTip = "Scales overall mask density/opacity from 0% (fully black) to 100% (full density).";

      this.opacityValue = new Edit( this );
      this.opacityValue.text = Math.round( this.maskOpacity * 100 ).toString() + "%";
      this.opacityValue.setFixedWidth( EDIT_WIDTH );

      this.opacitySlider.onValueUpdated = v => {
         this.maskOpacity = v / 100.0;
         this.opacityValue.text = v.toString() + "%";
         this.triggerUpdate();
      };

      this.opacityValue.onEditCompleted = () => {
         let val = parseInt( this.opacityValue.text );
         if ( isNaN( val ) ) val = 100;
         val = Math.max( 0, Math.min( 100, val ) );
         this.maskOpacity = val / 100.0;
         this.opacityValue.text = val.toString() + "%";
         this.opacitySlider.value = val;
         this.triggerUpdate();
      };

      let opacitySizer = new HorizontalSizer;
      opacitySizer.spacing = 6;
      opacitySizer.add( this.opacityLabel );
      opacitySizer.add( this.opacitySlider, 100 );
      opacitySizer.add( this.opacityValue );

      // ---- Render Delay Slider (0.0s to 1.0s) ----
      this.delayLabel = new Label( this );
      this.delayLabel.text = "Render Delay:";
      this.delayLabel.minWidth = SLIDER_LABEL_WIDTH;

      this.delaySlider = new Slider( this );
      this.delaySlider.minValue = 0;
      this.delaySlider.maxValue = 10;
      this.delaySlider.value = Math.round( this.debounceDelay * 10 );
      this.delaySlider.toolTip = "Delay before recalculating mask while moving sliders (0.0s = Instant, up to 1.0s). Higher values prevent UI lag on large images.";

      this.delayValue = new Edit( this );
      this.delayValue.text = format( "%.1fs", this.debounceDelay );
      this.delayValue.setFixedWidth( EDIT_WIDTH );

      this.delaySlider.onValueUpdated = v => {
         this.debounceDelay = v / 10.0;
         this.delayValue.text = format( "%.1fs", this.debounceDelay );
      };

      this.delayValue.onEditCompleted = () => {
         let val = parseFloat( this.delayValue.text );
         if ( isNaN( val ) ) val = 0.4;
         val = Math.max( 0.0, Math.min( 1.0, val ) );
         this.debounceDelay = val;
         this.delayValue.text = format( "%.1fs", this.debounceDelay );
         this.delaySlider.value = Math.round( val * 10 );
      };

      let delaySizer = new HorizontalSizer;
      delaySizer.spacing = 6;
      delaySizer.add( this.delayLabel );
      delaySizer.add( this.delaySlider, 100 );
      delaySizer.add( this.delayValue );

      // ---- Group Box for Mask Controls ----
      this.maskControlsBox = new GroupBox( this );
      this.maskControlsBox.title = "Mask Controls";
      let maskControlsSizer = new VerticalSizer;
      maskControlsSizer.margin = 8;
      maskControlsSizer.spacing = 6;
      maskControlsSizer.add( fuzzSizer );
      maskControlsSizer.add( blurSizer );
      maskControlsSizer.add( opacitySizer );
      maskControlsSizer.add( delaySizer );
      this.maskControlsBox.sizer = maskControlsSizer;

      this.syncCheckBox = new CheckBox( this );
      this.syncCheckBox.text = "Sync Between Source and Mask Views (Lock Zoom/Pan)";
      this.syncCheckBox.toolTip = "Forces both the Source and Mask previews to stay at the identical zoom and position.";
      this.syncCheckBox.checked = false;
      this.syncCheckBox.onCheck = (checked) => {
         if (checked) {
            this.isProgrammaticZoomUpdate = true;
            this.maskZoomCombo.currentItem = this.inputZoomCombo.currentItem;
            this.isProgrammaticZoomUpdate = false;

            this.maskPreview.zoomIndex = this.inputPreview.zoomIndex;
            this.updateSinglePreview( this.maskPreview );
            this.maskPreview.scrollPosition = this.inputPreview.scrollPosition;
            this.maskPreview.viewport.update();
         } else {
            // Unsync action: Reset Mask view back to maximum zoomed out (1:10)
            this.maskZoomCombo.currentItem = 9;
            this.maskPreview.zoomIndex = 9;
            this.updateSinglePreview( this.maskPreview );
         }
      };

      this.overviewLabel = new Label( this );
      this.overviewLabel.text = "Navigator";
      this.overviewLabel.textAlignment = 0x0004 | 0x0080;
      this.overviewLabel.minWidth = 150; // same as mini-map width
      this.overviewLabel.maxWidth = 150; // lock it to same width
      this.overviewLabel.styleSheet = "QLabel { font-weight: bold; font-size: 9pt; color: #333333; padding-left: 4px; }";

      this.overviewControl = new OverviewControl( this );

      let mapGuideLabel = new Label( this );
      mapGuideLabel.text = "• Click or drag the red square to quickly\n   navigate within the Source image.";
      mapGuideLabel.wordWrap = true;
      mapGuideLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

      let mapHBox = new HorizontalSizer;
      mapHBox.spacing = 10;
      mapHBox.add( this.overviewControl );
      mapHBox.add( mapGuideLabel, 100 );

      let mapSizer = new VerticalSizer;
      mapSizer.spacing = 2;
      mapSizer.add( this.overviewLabel );
      mapSizer.add( mapHBox );

      // ---- Action Buttons ----
      this.applyButton = new PushButton( this );
      this.applyButton.text = "Create Mask";
      this.applyButton.defaultButton = true;
      this.applyButton.onClick = () => this.applyMask();

      this.closeButton = new PushButton( this );
      this.closeButton.text = "Close";
      this.closeButton.onClick = () => this.ok();

      this.resetButton = new PushButton( this );
      this.resetButton.text = "Reset Defaults";
      this.resetButton.toolTip = "Restores all settings, sliders, and zoom levels to their original default values.";
      this.resetButton.onClick = () => {
         this.linearImage_Cb.checked = false;
         this.invertMask_Cb.checked = false;
         this.multiSelect_Cb.checked = false;
         this.syncCheckBox.checked = false;

         this.sampleSizeCombo.currentItem = 0;
         this.cursorCombo.currentItem = 0;
         this.inputPreview.setCursorStyle( 0 );
         this.maskPreview.setCursorStyle( 0 );

         this.fuzziness = 0.20;
         this.fuzzSlider.value = 20;
         this.fuzzValue.text = "20";

         this.blurRadius = 0.0;
         this.blurSlider.value = 0;
         this.blurValue.text = "0.0";

         this.maskOpacity = 1.0;
         this.opacitySlider.value = 100;
         this.opacityValue.text = "100%";

         this.debounceDelay = 0.40;
         this.delaySlider.value = 4;
         this.delayValue.text = "0.4s";
         this.updateTimer.interval = 0.40;

         this.isProgrammaticZoomUpdate = true;
         this.inputZoomCombo.currentItem = 9;
         this.maskZoomCombo.currentItem = 9;
         this.isProgrammaticZoomUpdate = false;
         this.inputPreview.zoomIndex = 9;
         this.maskPreview.zoomIndex = 9;

         this.updateTargetImage();
      };

      let btnSizer = new HorizontalSizer;
      btnSizer.add( this.applyButton );
      btnSizer.addSpacing( 10 );
      btnSizer.add( this.closeButton );
      btnSizer.addStretch();
      btnSizer.add( this.resetButton );

      this.leftSizer = new VerticalSizer;
      this.leftSizer.margin = 10;
      this.leftSizer.spacing = 8;
      this.leftSizer.add( this.titleLabel );
      this.leftSizer.add( this.instructionsBox );
      this.leftSizer.addSpacing( 5 );
      this.leftSizer.add( imgSizer );
      this.leftSizer.add( checksSizer );
      this.leftSizer.addSpacing( 5 );
      this.leftSizer.add( sampleSizeSizer );
      this.leftSizer.add( cursorSizer );
      this.leftSizer.add( colorSizer );
      this.leftSizer.add( this.maskControlsBox );
      this.leftSizer.addSpacing( 5 );
      this.leftSizer.add( this.syncCheckBox );
      this.leftSizer.addSpacing( 5 );
      this.leftSizer.add( mapSizer );
      this.leftSizer.addStretch();
      this.leftSizer.add( btnSizer );

      this.inputPreview = new ImagePreviewControl( this, true );
      this.inputPreview.setMinWidth( 550 );
      this.inputPreview.setMinHeight( 550 );

      this.maskPreview = new ImagePreviewControl( this, false );
      this.maskPreview.setMinWidth( 550 );
      this.maskPreview.setMinHeight( 550 );

      this.inputPreview.syncControl = this.maskPreview;
      this.maskPreview.syncControl = this.inputPreview;
      this.overviewControl.mainPreview = this.inputPreview;
      this.inputPreview.parentDialog = this;
      this.maskPreview.parentDialog = this;

      let populateZoom = (combo) => {
         combo.addItem( "4:1" ); // 0
         combo.addItem( "3:1" ); // 1
         combo.addItem( "2:1" ); // 2
         combo.addItem( "1:1" ); // 3
         combo.addItem( "1:2" ); // 4
         combo.addItem( "1:3" ); // 5
         combo.addItem( "1:4" ); // 6
         combo.addItem( "1:6" ); // 7
         combo.addItem( "1:8" ); // 8
         combo.addItem( "1:10" ); // 9
      };

      this.inputZoomCombo = new ComboBox( this );
      populateZoom( this.inputZoomCombo );
      this.inputZoomCombo.currentItem = 9;
      this.inputZoomCombo.toolTip = "Zoom level for the Source Image.";
      this.inputZoomCombo.onItemSelected = (i) => {
         if ( this.isProgrammaticZoomUpdate ) return;
         this.inputPreview.zoomIndex = i;
         this.updateSinglePreview( this.inputPreview );
         if ( this.syncCheckBox.checked ) {
            this.isProgrammaticZoomUpdate = true;
            this.maskZoomCombo.currentItem = i;
            this.isProgrammaticZoomUpdate = false;
            this.maskPreview.zoomIndex = i;
            this.updateSinglePreview( this.maskPreview );
            this.maskPreview.scrollPosition = this.inputPreview.scrollPosition;
            this.maskPreview.viewport.update();
         }
      };

      this.maskZoomCombo = new ComboBox( this );
      populateZoom( this.maskZoomCombo );
      this.maskZoomCombo.currentItem = 9;
      this.maskZoomCombo.toolTip = "Zoom level for the Generated Mask.";
      this.maskZoomCombo.onItemSelected = (i) => {
         if ( this.isProgrammaticZoomUpdate ) return;
         this.maskPreview.zoomIndex = i;
         this.updateSinglePreview( this.maskPreview );
         if ( this.syncCheckBox.checked ) {
            this.isProgrammaticZoomUpdate = true;
            this.inputZoomCombo.currentItem = i;
            this.isProgrammaticZoomUpdate = false;
            this.inputPreview.zoomIndex = i;
            this.updateSinglePreview( this.inputPreview );
            this.inputPreview.scrollPosition = this.maskPreview.scrollPosition;
            this.maskPreview.viewport.update();
         }
      };

      this.inputPreview.zoomIndex = 9;
      this.maskPreview.zoomIndex = 9;

      let lblInput = new Label( this );
      lblInput.text = "Source Image";
      lblInput.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      lblInput.styleSheet = "QLabel { font-weight: bold; }";

      let lblInputZoom = new Label( this );
      lblInputZoom.text = "Zoom:";
      lblInputZoom.textAlignment = TextAlign_Right | TextAlign_VertCenter;

      let inputHeadSizer = new HorizontalSizer;
      inputHeadSizer.spacing = 6;
      inputHeadSizer.add( lblInput );
      inputHeadSizer.addStretch();
      inputHeadSizer.add( lblInputZoom );
      inputHeadSizer.add( this.inputZoomCombo );

      let lblMask = new Label( this );
      lblMask.text = "Generated Mask";
      lblMask.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      lblMask.styleSheet = "QLabel { font-weight: bold; }";

      let lblMaskZoom = new Label( this );
      lblMaskZoom.text = "Zoom:";
      lblMaskZoom.textAlignment = TextAlign_Right | TextAlign_VertCenter;

      let maskHeadSizer = new HorizontalSizer;
      maskHeadSizer.spacing = 6;
      maskHeadSizer.add( lblMask );
      maskHeadSizer.addStretch();
      maskHeadSizer.add( lblMaskZoom );
      maskHeadSizer.add( this.maskZoomCombo );

      let topLblSizer = new HorizontalSizer;
      topLblSizer.spacing = 15;
      topLblSizer.add( inputHeadSizer, 100 );
      topLblSizer.add( maskHeadSizer, 100 );

      let previewHBox = new HorizontalSizer;
      previewHBox.spacing = 15;
      previewHBox.add( this.inputPreview, 100 );
      previewHBox.add( this.maskPreview, 100 );

      let rightSizer = new VerticalSizer;
      rightSizer.margin = 10;
      rightSizer.spacing = 6;
      rightSizer.add( topLblSizer );
      rightSizer.add( previewHBox, 100 );

      this.sizer = new HorizontalSizer;
      this.sizer.add( this.leftSizer );
      this.sizer.add( rightSizer, 100 );
   }

   handleWheelZoom( ctrl, delta, x, y )
   {
      let isZoomIn = delta > 0;
      let newIndex = ctrl.zoomIndex;

      if ( isZoomIn ) newIndex = Math.max( 0, newIndex - 1 );
      else newIndex = Math.min( 9, newIndex + 1 );

      if ( newIndex !== ctrl.zoomIndex )
      {
         ctrl.zoomIndex = newIndex;

         let combo = (ctrl.isInput) ? this.inputZoomCombo : this.maskZoomCombo;
         this.isProgrammaticZoomUpdate = true;
         combo.currentItem = newIndex;
         this.isProgrammaticZoomUpdate = false;

         this.updateSinglePreview( ctrl, x, y );

         if ( this.syncCheckBox.checked )
         {
            let otherCtrl = (ctrl.isInput) ? this.maskPreview : this.inputPreview;
            let otherCombo = (ctrl.isInput) ? this.maskZoomCombo : this.inputZoomCombo;

            otherCtrl.zoomIndex = newIndex;
            this.isProgrammaticZoomUpdate = true;
            otherCombo.currentItem = newIndex;
            this.isProgrammaticZoomUpdate = false;

            this.updateSinglePreview( otherCtrl, x, y );
         }
      }
   }

   cleanUp()
   {
      if ( this.srcWin ) { this.srcWin.forceClose(); this.srcWin = null; }
      if ( this.maskWin ) { this.maskWin.forceClose(); this.maskWin = null; }
   }

   updateTargetImage()
   {
      this.cleanUp();
      this.sampledColors = [];
      this.updateColorDisplays();

      if ( this.imageCombo.numberOfItems === 0 ) return;
      let targetId = this.imageCombo.itemText( this.imageCombo.currentItem );
      let targetView = View.viewById( targetId );
      if ( targetView.isNull ) return;

      this.srcWin = new ImageWindow(
         targetView.image.width, targetView.image.height,
         targetView.image.numberOfChannels, targetView.image.bitsPerSample,
         targetView.image.isReal, targetView.image.isColor, "tmp_src_" + Date.now()
      );
      this.srcWin.mainView.beginProcess();
      this.srcWin.mainView.image.assign( targetView.image );
      this.srcWin.mainView.endProcess();

      // PixelMath AutoSTF Routine
      if ( this.linearImage_Cb.checked )
      {
         let P = new PixelMath;
         P.expression =
            "C = -2.8;\n" +
            "B = 0.20;\n" +
            "c = min(max(0,med($T)+C*1.4826*mdev($T)),1);\n" +
            "mtf(mtf(B,med($T)-c),max(0,($T-c)/~c))";
         P.useSingleExpression = true;
         P.symbols = "C,B,c";
         P.createNewImage = false;

         Console.enabled = false;
         try { P.executeOn( this.srcWin.mainView ); }
         finally { Console.enabled = true; }
      }

      this.maskWin = new ImageWindow(
         targetView.image.width,
         targetView.image.height,
         1,
         targetView.image.bitsPerSample,
         targetView.image.isReal,
         false,
         "tmp_mask_" + Date.now()
      );

      this.overviewControl.doUpdateThumbnail( this.srcWin.mainView.image );

      // Startup Default: Clear the mask initially (no colors selected)
      this.maskWin.mainView.beginProcess();
      let emptyVal = this.invertMask_Cb.checked ? 1.0 : 0.0;
      this.maskWin.mainView.image.fill( emptyVal );
      this.maskWin.mainView.endProcess();

      this.updateSinglePreview( this.inputPreview );
      this.updateSinglePreview( this.maskPreview );
   }

   onColorPickedXY( x, y )
   {
      if ( !this.srcWin ) return;
      let img = this.srcWin.mainView.image;

      let size = 1;
      if (this.sampleSizeCombo.currentItem === 1) size = 3;
      else if (this.sampleSizeCombo.currentItem === 2) size = 5;
      let halfPoint = Math.floor(size / 2);

      let sumR = 0, sumG = 0, sumB = 0, count = 0;

      for (let dx = -halfPoint; dx <= halfPoint; dx++) {
         for (let dy = -halfPoint; dy <= halfPoint; dy++) {
            let cx = x + dx;
            let cy = y + dy;
            if (cx >= 0 && cx < img.width && cy >= 0 && cy < img.height) {
               let r = img.sample(cx, cy, 0);
               let g = img.isColor ? img.sample(cx, cy, 1) : r;
               let b = img.isColor ? img.sample(cx, cy, 2) : r;
               sumR += r; sumG += g; sumB += b;
               count++;
            }
         }
      }

      if (count > 0) {
         let r = sumR / count;
         let g = sumG / count;
         let b = sumB / count;

         if (!this.multiSelect_Cb.checked) {
            this.sampledColors = [];
         }
         this.sampledColors.push({ r: r, g: g, b: b });

         this.updateColorDisplays();
         this.refreshMask();
      }
   }

   updateColorDisplays()
   {
      this.colorPatch.setColors(this.sampledColors);
      if (this.sampledColors.length > 0) {
         let last = this.sampledColors[this.sampledColors.length - 1];
         this.colorValues.text = format("R: %.2f  G: %.2f  B: %.2f (Total: %d)", last.r, last.g, last.b, this.sampledColors.length);
      } else {
         this.colorValues.text = "R: 0.00  G: 0.00  B: 0.00 (Total: 0)";
      }
   }

   refreshMask()
   {
      if ( !this.srcWin || !this.maskWin ) return;

      if (this.sampledColors.length === 0) {
         this.maskWin.mainView.beginProcess();
         let emptyVal = this.invertMask_Cb.checked ? 1.0 : 0.0;
         this.maskWin.mainView.image.fill(emptyVal);
         this.maskWin.mainView.endProcess();
         this.updateSinglePreview( this.maskPreview );
         return;
      }

      let fScaled = Math.max( 0.001, this.fuzziness * 1.75 );
      let srcId = this.srcWin.mainView.id;
      let expressions = [];

      for (let i = 0; i < this.sampledColors.length; i++) {
         let c = this.sampledColors[i];
         let distExpr = "";
         if ( this.srcWin.mainView.image.isColor ) {
            let rDiff = "(" + srcId + "[0] - " + c.r.toFixed(6) + ")";
            let gDiff = "(" + srcId + "[1] - " + c.g.toFixed(6) + ")";
            let bDiff = "(" + srcId + "[2] - " + c.b.toFixed(6) + ")";
            distExpr = "sqrt(" + rDiff + "*" + rDiff + " + " + gDiff + "*" + gDiff + " + " + bDiff + "*" + bDiff + ")";
         } else {
            distExpr = "abs(" + srcId + " - " + c.r.toFixed(6) + ")";
         }
         expressions.push("max(0, 1 - (" + distExpr + " / " + fScaled.toFixed(6) + "))");
      }

      let finalExpr = expressions[0];
      for (let i = 1; i < expressions.length; i++) {
         finalExpr = "max(" + finalExpr + ", " + expressions[i] + ")";
      }

      if ( this.invertMask_Cb.checked ) {
         finalExpr = "1 - (" + finalExpr + ")";
      }

      var PM = new PixelMath;
      PM.expression = finalExpr;
      PM.useSingleExpression = true;
      PM.createNewImage = false;

      Console.enabled = false;
      try
      {
         // Step 1: Base Color Distance Mask Calculation
         PM.executeOn( this.maskWin.mainView );

         // Step 2: Mask Opacity Scaling
         if ( this.maskOpacity < 0.999 )
         {
            var PM_op = new PixelMath;
            PM_op.useSingleExpression = true;
            PM_op.createNewImage = false;
            PM_op.expression = "$T * " + this.maskOpacity.toFixed(4);
            PM_op.executeOn( this.maskWin.mainView );
         }

         // Step 3: Gaussian Blur Softening
         if ( this.blurRadius > 0 )
         {
            var conv = new Convolution;
            conv.mode = 0;
            conv.sigma = this.blurRadius;
            conv.shape = 2.0;
            conv.aspectRatio = 1.0;
            conv.executeOn( this.maskWin.mainView );
         }
      }
      finally
      {
         Console.enabled = true;
      }

      this.updateSinglePreview( this.inputPreview );
      this.updateSinglePreview( this.maskPreview );
   }

   updateSinglePreview( ctrl, cursorX, cursorY )
   {
      if ( !this.srcWin ) return;
      let srcImg = (ctrl.isInput) ? this.srcWin.mainView.image : this.maskWin.mainView.image;
      let resampledImg = this.getResampled( srcImg, ctrl.zoomIndex );

      let cx = (cursorX !== undefined) ? cursorX : (ctrl.viewport.width / 2);
      let cy = (cursorY !== undefined) ? cursorY : (ctrl.viewport.height / 2);

      ctrl.updateImage( resampledImg, srcImg, cx, cy );
   }

   getResampled( img, zoomIndex )
   {
      if ( zoomIndex === 3 ) return new Image( img ); // 1:1

      let w = new ImageWindow( img.width, img.height, img.numberOfChannels, img.bitsPerSample, img.isReal, img.isColor );
      w.mainView.beginProcess();
      w.mainView.image.assign( img );
      w.mainView.endProcess();

      let P = new IntegerResample;
      switch( zoomIndex )
      {
         case 0: P.zoomFactor = 4; break;
         case 1: P.zoomFactor = 3; break;
         case 2: P.zoomFactor = 2; break;
         case 4: P.zoomFactor = -2; break;
         case 5: P.zoomFactor = -3; break;
         case 6: P.zoomFactor = -4; break;
         case 7: P.zoomFactor = -6; break;
         case 8: P.zoomFactor = -8; break;
         case 9: P.zoomFactor = -10; break;
      }

      P.executeOn( w.mainView );
      let resultImg = new Image( w.mainView.image );
      w.forceClose();

      return resultImg;
   }

   applyMask()
   {
      if ( !this.maskWin ) return;

      this.updateTimer.stop();
      this.refreshMask();

      let targetId = this.imageCombo.itemText( this.imageCombo.currentItem );

      let finalMask = new ImageWindow(
         this.maskWin.mainView.image.width,
         this.maskWin.mainView.image.height,
         1,
         this.maskWin.mainView.image.bitsPerSample,
         this.maskWin.mainView.image.isReal,
         false,
         "ColorMask"
      );

      finalMask.mainView.beginProcess();
      finalMask.mainView.image.assign( this.maskWin.mainView.image );
      finalMask.mainView.endProcess();

      finalMask.show();
      finalMask.zoomToFit();

   }
};

//---------------------------------------------------------
// Main Function
//---------------------------------------------------------
function main()
{
   if ( ImageWindow.windows.length === 0 )
   {
      new MessageBox(
         "Please open at least one image to use the Color Range Selection script.",
         "Error",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return;
   }

   let dialog = new ColorRangeDialog();
   dialog.execute();
   dialog.cleanUp();
}

main();
